-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."tech_tree_branches" ("id", "dealer_id", "slug", "name", "source_url", "verification_status")
values
('189d3374-62cf-4eab-881e-e055cb364d6b', '8548348f-6cdb-4f80-b0f6-d007c079968d', 'russian_fire_support', 'Russian Fire Support', 'https://armoredwarfare.com/en/news/general/branch-month-russian-fire-support', 'needs_ingame_check')
on conflict ("id") do nothing;
commit;
