-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."vehicle_crew_positions" ("vehicle_id", "position_key", "role", "occupant_count", "location", "note", "source_url", "source_type", "verification_status")
values
('1456a180-e7b6-4f14-a4d7-e27b85eff6d8', 'commander', 'commander', 1, NULL, 'Wiki Crew 明确列出；Commander 单独计入总岗位，不等同可训练车组人数。', 'https://armoredwarfare.fandom.com/wiki/B1_Centauro_120', 'wiki', 'needs_ingame_check'),
('1456a180-e7b6-4f14-a4d7-e27b85eff6d8', 'driver', 'driver', 1, NULL, 'Wiki Crew 明确列出；Commander 单独计入总岗位，不等同可训练车组人数。', 'https://armoredwarfare.fandom.com/wiki/B1_Centauro_120', 'wiki', 'needs_ingame_check'),
('1456a180-e7b6-4f14-a4d7-e27b85eff6d8', 'gunner', 'gunner', 1, NULL, 'Wiki Crew 明确列出；Commander 单独计入总岗位，不等同可训练车组人数。', 'https://armoredwarfare.fandom.com/wiki/B1_Centauro_120', 'wiki', 'needs_ingame_check'),
('1456a180-e7b6-4f14-a4d7-e27b85eff6d8', 'loader', 'loader', 1, NULL, 'Wiki Crew 明确列出；Commander 单独计入总岗位，不等同可训练车组人数。', 'https://armoredwarfare.fandom.com/wiki/B1_Centauro_120', 'wiki', 'needs_ingame_check')
on conflict ("vehicle_id", "position_key") do nothing;
commit;
