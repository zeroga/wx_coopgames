-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."ammo_traits" ("code", "name_zh", "category", "description")
values
('direct_attack', '直射', 'attack_profile', NULL),
('kinetic_missile', '动能导弹', 'warhead', NULL),
('multipurpose', '多用途', 'warhead', NULL),
('pele', 'PELE 穿甲后效', 'effect', NULL),
('programmable', '可编程', 'effect', NULL),
('recon', '侦察弹药', 'effect', NULL),
('tandem', '串联战斗部', 'warhead', NULL),
('thermobaric', '热压', 'warhead', NULL),
('top_attack', '攻顶', 'attack_profile', NULL)
on conflict ("code") do nothing;
commit;
