-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."unlock_paths" ("id", "vehicle_id", "slug", "name", "sort_order", "note", "target_upgrade_id", "is_complete")
values
('f9ba3cfe-2f73-45df-9878-f09f9a490af9', '65842847-d2b0-4338-8259-976461be0f6f', 'from_griffin_50mm', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('f9e44f6c-fcc5-4a27-8fdf-b3f540533b59', '5a76d22a-af77-4198-b294-a77b63ea553e', 'from_bvp_m2_skcz_sakal', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('fb4b3e32-df0c-4321-971b-5fa6e945c895', '6b3104a0-8dc1-4006-91b0-c08916469680', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('fb71547c-3150-482b-b888-ec3eda7cedf0', '3d156b33-f61c-4f7b-b1ba-8e747f46056e', 'from_kto_rosomak', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('fb85273c-96a9-43aa-b747-d7e32d99ec54', '3cc27c76-83b9-493a-8f4e-62dbf00cd463', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('fbbec4d6-630d-461a-b498-ad2137da2122', '62b35f0e-9f21-4f6d-8d5c-80669d931d1a', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('fbc5c2fd-75b2-45cf-a1b4-47b27ba203d7', '7245b00d-b3f2-4b77-a59a-b97ba9274ac0', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('fc44ea5c-c127-4650-9a80-7f6a06c4e653', '5ee222ba-5532-4796-95e5-eabf96efd5e0', 'from_harimau', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('fd435855-7500-489c-bd91-f92accbfb1e4', '7d732373-6f59-4519-99b9-2e3f56650ba5', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('fe9e3fd0-dee1-437e-a411-873658748766', '6c1f2047-1a30-4108-804f-bf58da0082b7', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('fea69901-aed5-450e-918a-c9d4d2c7c968', '34a36588-48ca-4c89-9eee-107e38e074b0', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('feb4c984-105b-4c97-848a-8497dfd24553', 'a71748b3-121e-49f7-8cb0-2f1e0f2e87a3', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', 'b172acfb-7fb8-4ede-b64d-2a25300e3956', false),
('ff3a470c-0f3f-4201-aaab-f3d745669291', '8e1bf45a-1785-4723-a8c1-50701a414f8f', 'from_bmp_1', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('fff488bb-6a8a-483c-8a88-d06d28ae3439', '87fe99cd-7142-4e68-9499-e1eb3ca6c9ba', 'from_centurion_mk_11', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false)
on conflict ("id") do nothing;
commit;
