-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."unlock_paths" ("id", "vehicle_id", "slug", "name", "sort_order", "note", "target_upgrade_id", "is_complete")
values
('980229af-a849-4a72-9f62-fbc421c85875', '1d20318a-3c06-4a09-abed-08596903b5d5', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('985dd199-26c4-4905-983b-55a4d3ddf876', '7909041f-33b6-4ed7-a069-3d21293444a4', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('9901857e-1e1a-4d87-9e60-eb13b3d16282', 'cf4b5018-1ae4-46c6-9580-c9e1d8736705', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('9a87d04c-f489-4647-a922-64e17e1dc1b3', '78a63324-39db-4536-a4a3-3b5087f57ea0', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('9b2b24a9-9d4f-4e8a-a41b-62c38f82d969', 'fb5f8035-4e26-46bd-8750-3a41133a638c', 'from_type_90_ii', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('9b924540-c1b3-4541-918c-340dd184912f', '6fed8188-0525-4670-a85b-b7ad1ddc1bf1', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('9dc06d0b-305f-4916-be3e-82df3d8de9c0', '04e2d20d-122d-4433-8b36-bb1c859b9e85', 'from_magach_5', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('9de715d0-71ba-4778-b4f3-40cf3c0e62a6', 'e1bc1269-a58c-4181-aec8-5b84c16c0f10', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('9e075330-287f-46e3-9e06-2cc669057b5a', '6b4e302d-20cc-428d-a4b7-119f13dfd495', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '67d76f84-a1e6-4b83-98d7-824c7524276f', true),
('9e4a072c-c923-4cb4-b522-3942fec53fbf', '745282a9-c687-46cc-96a6-fa36b0c67053', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('9e526588-e883-4183-a646-35abc8fd53a3', '56090e37-93a7-421a-8953-4779867b1965', 'from_tank_test_bed', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('9f50f936-fa9a-4202-ae7e-b1c28f3ebee6', '6138e381-07bb-4802-913d-e139628d318a', 'from_type_80_ii', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('a05dacf4-d90a-4605-9767-bda872194f59', '1a424f52-548a-4dd0-9ce7-ba069fbd1330', 'from_vbl_ingwe', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('a133996d-2286-4c4e-b113-096460d3846d', '38358ca3-fecb-44de-9ee4-d3ee56c02da9', 'from_leclerc', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('a44a80df-46e3-405a-8c4d-fb361dc0aa1a', 'bb6938fd-15ed-49a1-b5c4-33ecbce45bbb', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('a489e9a0-bb3e-4a50-be10-0a2afeff81b9', 'e8e6639a-c376-4841-bb61-6d456a3af743', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('a533a998-f3b8-44c4-ba09-45e2825abb1d', '6663f7d9-3d5c-4062-a2bc-dfa136eeb441', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('a554ac29-e871-4452-af02-71f80e1a730a', 'c30bb45b-a45e-403d-aab0-ac1b4f756039', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('a61f6f33-537f-4240-a3ed-d890f248c16c', '71cbdb82-de7a-412a-a8bd-504de820118d', 'from_fv107_scimitar', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('a643d53c-6f17-4435-ad42-58f8a0a10731', 'c2d68eab-b21d-4a24-805c-d119c0a184a1', 'from_type_69', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('a7269166-875b-48c1-94f6-57a63cce2fac', 'a24b076c-b145-4585-9c93-1b91f2b5427a', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('a742526b-b30e-4b64-a1c0-5f16001dc5e3', 'ed91ca94-3aea-438c-8586-a2484668a39c', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('a815f5a3-3d31-4522-8673-ddcc4929b473', '3f8a9418-4da7-47d8-a7d8-001c35c37785', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('a8230161-b40c-4178-9ed8-f3b81e2f35fa', '2a1c4f58-a2f4-44e7-a2ce-11d0e558e1f5', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('a9823cda-fc4b-4b0d-abe4-1947064b7679', 'e857f286-f531-48de-914c-26d4594cd177', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('aad480cb-0f64-4e35-99be-bb7f3a026f54', '1120c3fe-81dd-4f52-90f7-e8d4b7221158', 'from_2s1_gvozdika', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('abcb73b0-dca3-41ad-8e8b-f7af36a2415c', '7553090c-2d92-4501-a194-86b11203b13c', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('abe66782-4683-49fd-b4c9-feee3119b498', '3cae0e4f-fa3a-41ee-81ed-e17a030cc22b', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('aceab809-a343-4637-a72e-6fdcab0ebd42', 'bb2d6832-5e85-48be-bab4-e6a5dc83633a', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('ad23239e-79a8-460d-ada6-86db602a4e80', 'd1b7446a-f854-49dd-b8c3-071538897db6', 'from_zbl_08', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('ada945f7-3aab-4904-b709-7cb3cf0afa0b', '8c3772e3-9ada-47d3-8f42-08d04fed7882', 'from_m60_patton', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('b058014a-0b59-4fb6-a434-22109ba8becb', '9874e316-c43b-4c90-aef0-617cbec483f5', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('b0c50369-12da-4c74-a645-3cf8cf69befd', 'a6e788c5-890b-4a63-9fde-feab9be64175', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('b1084d00-3235-46f4-832a-baedbb60d663', '35afb50f-db0a-4e9b-8e2e-e91b3d63a482', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('b1202b46-cca1-4257-8386-1117c7f380fd', '642cef03-079e-4cde-8389-9b3ac213abdb', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '25c3167e-cab2-4c46-b6ab-d173ab6a40af', true),
('b182c789-c66e-45e9-9a76-34157260ba04', 'aa519126-7bb9-4d45-886b-72d1d58f448b', 'from_m108', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('b2a34f2b-ed5b-40d2-b50f-134491d790c4', '8e1bf45a-1785-4723-a8c1-50701a414f8f', 'from_bmd_1p', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('b4fa3843-2d6d-471c-a2a4-ae68e2bfe1d4', 'd4e23d6b-c48d-4e6a-8695-a00b0652f85d', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('b63cae68-dd98-4152-a9c2-59d37af7c0a3', '8c3b833c-da75-44d4-a54b-9426cd3f94cc', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('b6d32767-2983-4562-8a0f-c3d273e3a676', 'ec18252a-5986-4e11-a24f-5e76c23f75cf', 'from_m60_patton', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('b6ea7904-0cd7-486f-8632-ffa4b81a92fd', 'ed995280-7545-4985-94a7-e9baf12d70a2', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('b7c96346-8726-441f-b0f7-f438cfaf85f7', '9212d07e-77bb-4745-897c-00712bb5681f', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('b7d115e6-e6de-45fa-a585-0c6b84be95e6', '42324be7-c4fa-4a01-b764-c575ee0bc0db', 'from_fv101_scorpion_90', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('b877545f-d713-4801-b00d-30055c12b028', 'f3e399a2-7ab5-4e59-b692-09982ed5f520', 'from_chieftain_mk_10', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('b98ea05a-b90a-41ed-80fd-4fbaebaf9ff9', 'c2bfdc4f-3489-48c8-ae7f-734f1821ea70', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('bafd044f-4a0e-41fb-aa60-ed7250b645fa', '4d2938db-e82f-49ce-9a84-f0f8b661bf9e', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('bba0ebd2-b723-431b-9965-da6047821f45', 'eafab0a3-55dd-4936-a131-a8577e2c2330', 'from_t_72_ural', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('bcf68afa-0378-42e7-98bf-65915798b681', 'a87f47b1-1404-4cac-900c-ac3e40a29609', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('bdaad0c0-f007-4d20-af34-153b14036c27', '4a63fa8e-983b-4c5e-b477-3fd39845f1f9', 'from_2s25_sprut_sd', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('bde9e194-092d-46cd-b28b-b1c901896cf9', 'eafab0a3-55dd-4936-a131-a8577e2c2330', 'from_t_64a_mod_1976', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false)
on conflict ("id") do nothing;
commit;
