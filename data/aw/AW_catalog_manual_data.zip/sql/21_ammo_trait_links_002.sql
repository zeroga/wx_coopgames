-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."ammo_trait_links" ("ammo_id", "trait_code", "source_url", "source_type", "verification_status")
values
('d68343d8-d60e-4522-8396-38bb19e51ae0', 'pele', 'https://armoredwarfare.fandom.com/wiki/Namer_IFV', 'wiki', 'needs_ingame_check'),
('dbd00d9b-e744-4791-867a-c2f799cd5bd3', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Leopard_Evolution', 'wiki', 'needs_ingame_check'),
('ddc8c238-bb98-42fc-8b00-bd45300e6dca', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Leopard_Evolution', 'wiki', 'needs_ingame_check'),
('dedb5a1f-6943-4fb7-b02d-574ea375c93f', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/M1A2_Abrams', 'wiki', 'needs_ingame_check'),
('dfa833ef-f777-4f99-8f6d-1c2afb216b5b', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Stridsvagn_122', 'wiki', 'needs_ingame_check'),
('e12466f4-2b7b-4e1e-aad8-fcf364d0bdac', 'thermobaric', 'https://armoredwarfare.com/en/news/general/development-zbd-100', 'official', 'needs_ingame_check'),
('e1674dd9-2ad3-48dc-b585-5fdae2162293', 'tandem', 'https://armoredwarfare.com/en/news/general/development-zbd-100', 'official', 'needs_ingame_check'),
('e1ef9873-6687-4027-a33f-c32948d9894f', 'programmable', 'https://armoredwarfare.fandom.com/wiki/T-14_152_Hades', 'wiki', 'needs_ingame_check'),
('e37c893b-efed-42ce-841c-8677437952d6', 'pele', 'https://armoredwarfare.fandom.com/wiki/AS21_Redback', 'wiki', 'needs_ingame_check'),
('e3c28bd8-6d2a-43c6-ba59-0bdaaf881eb8', 'kinetic_missile', 'https://armoredwarfare.fandom.com/wiki/M8_MGM-166', 'wiki', 'needs_ingame_check'),
('e4b8669f-b399-4dcd-be53-d71f9ace2b4d', 'tandem', 'https://armoredwarfare.fandom.com/wiki/SPHINX', 'wiki', 'needs_ingame_check'),
('e4e2607e-fa3c-4eb8-b291-db77edddde9a', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Al-Hussein_Hybrid', 'wiki', 'needs_ingame_check'),
('e68b0bd2-3529-4315-8053-b4ac2175ed06', 'pele', 'https://armoredwarfare.fandom.com/wiki/EBRC_Jaguar', 'wiki', 'needs_ingame_check'),
('ed73b454-5345-49ee-939c-1d65520e18df', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/XM1A3', 'wiki', 'needs_ingame_check'),
('edc467a4-26fa-4a90-8845-628d7862ca17', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/AMX-40', 'wiki', 'needs_ingame_check'),
('ede7862b-dd45-4bcf-95e5-d47db7ae972f', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Leopard_2A6_Hades', 'wiki', 'needs_ingame_check'),
('f2e4c954-0794-4f0b-a4c3-b15d09041461', 'pele', 'https://armoredwarfare.fandom.com/wiki/Borsuk', 'wiki', 'needs_ingame_check'),
('f3cc10d3-a5ea-4dba-8839-70da9caf12d2', 'top_attack', 'https://armoredwarfare.fandom.com/wiki/AS21_Redback', 'wiki', 'needs_ingame_check'),
('f7b6443a-a5e2-4d34-9273-a6cb938a9fcc', 'pele', 'https://armoredwarfare.fandom.com/wiki/Sch%C3%BCtzenpanzer_Puma', 'wiki', 'needs_ingame_check'),
('fb464797-d5cc-4860-b96d-1f3e109b6bf1', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Type_16_MCV', 'wiki', 'needs_ingame_check'),
('fb7657b8-220d-4cd3-b578-fe6cd8c7663c', 'tandem', 'https://armoredwarfare.fandom.com/wiki/Type_99A2', 'wiki', 'needs_ingame_check'),
('fec0b124-9731-45f8-baf7-8b859dfbf6f9', 'pele', 'https://armoredwarfare.fandom.com/wiki/KF41_Lynx_Prototype', 'wiki', 'needs_ingame_check')
on conflict ("ammo_id", "trait_code") do nothing;
commit;
