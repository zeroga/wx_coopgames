-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."vehicle_armor" ("id", "vehicle_id", "configuration_key", "location", "thickness_mm", "effective_ap_mm", "effective_heat_mm", "composition", "upgrade_id", "source_url", "source_type", "verification_status")
values
('07f384f9-20e6-4c28-899f-b0bfa8a75a49', '1456a180-e7b6-4f14-a4d7-e27b85eff6d8', 'source_summary', 'hull_unspecified', NULL, 110, 135, 'Steel', NULL, 'https://armoredwarfare.fandom.com/wiki/B1_Centauro_120', 'wiki', 'needs_ingame_check'),
('48c3e1e5-8357-4eed-b39d-bee36457bb56', '749f48fc-e226-4e0a-901a-16d428658482', 'source_summary', 'turret_unspecified', NULL, 380, 735, 'Steel', NULL, 'https://armoredwarfare.fandom.com/wiki/M8-120_Thunderbolt_II', 'wiki', 'needs_ingame_check'),
('8751f4e1-c946-40d2-b5fa-26482da7be05', '749f48fc-e226-4e0a-901a-16d428658482', 'source_summary', 'hull_unspecified', NULL, 180, 255, 'Steel', NULL, 'https://armoredwarfare.fandom.com/wiki/M8-120_Thunderbolt_II', 'wiki', 'needs_ingame_check'),
('9a5687cb-f304-4fce-b291-6d7aca01d04e', '1456a180-e7b6-4f14-a4d7-e27b85eff6d8', 'source_summary', 'turret_unspecified', NULL, 110, 145, 'Steel', NULL, 'https://armoredwarfare.fandom.com/wiki/B1_Centauro_120', 'wiki', 'needs_ingame_check')
on conflict ("id") do nothing;
commit;
