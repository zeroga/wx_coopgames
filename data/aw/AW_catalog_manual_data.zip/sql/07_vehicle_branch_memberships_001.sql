-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."vehicle_branch_memberships" ("vehicle_id", "branch_id", "display_order")
values
('329f42b2-3d6e-4b52-8dfd-e2c0d28820a8', '189d3374-62cf-4eab-881e-e055cb364d6b', 6),
('42324be7-c4fa-4a01-b764-c575ee0bc0db', '189d3374-62cf-4eab-881e-e055cb364d6b', 2),
('458043b1-7aeb-43d9-be91-5f1d09824b9a', '189d3374-62cf-4eab-881e-e055cb364d6b', 4),
('52324ba1-ee4b-4d2d-9693-a68c1c19064b', '189d3374-62cf-4eab-881e-e055cb364d6b', 1),
('5d4bb49c-885b-4741-a7ca-f53176644d5d', '189d3374-62cf-4eab-881e-e055cb364d6b', 5),
('a92e46a7-77f0-42a3-98ea-3949e7ac6ae7', '189d3374-62cf-4eab-881e-e055cb364d6b', 7),
('bf6b9d3b-42cf-4da7-a1f7-4f141971427f', '189d3374-62cf-4eab-881e-e055cb364d6b', 8),
('cdcb5a19-3818-4fdf-a9db-842b12cb06e0', '189d3374-62cf-4eab-881e-e055cb364d6b', 3)
on conflict ("vehicle_id", "branch_id") do nothing;
commit;
