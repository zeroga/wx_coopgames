-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."unlock_paths" ("id", "vehicle_id", "slug", "name", "sort_order", "note", "target_upgrade_id", "is_complete")
values
('bf0c4283-f3c5-4445-b7f7-ab7cdb0133d0', 'a71748b3-121e-49f7-8cb0-2f1e0f2e87a3', 'from_m113_acav', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('bfd55dbb-6a42-47da-a22b-4296c7d1f579', '37f65869-5927-431c-acf3-bd905716d3df', 'from_b1_centauro_105', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('c0264091-92c7-4d48-b90f-448acd9717f4', '9a1ea0fe-0127-4141-9f27-bd2bbbfce933', 'from_pt_85', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('c04ef6b9-8b70-4a4e-9ebc-599d64b40a44', '6b4e302d-20cc-428d-a4b7-119f13dfd495', 'from_xm800t_law', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('c096cb34-806f-43aa-8f46-1b5621dba22d', '77994a73-a1d6-4267-aacf-6784fc37f612', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('c0f9b437-7c72-40bf-8e8f-5982f8794583', 'ebb14f82-3e5d-474a-8618-7a2a22f14636', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('c256dcf8-55fb-40c2-b70f-b09d44642903', 'f0ed1a63-b1e6-4cf6-bfb7-dd13048642e0', 'from_leopard_2av', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('c258fcde-dcc4-4d17-8c73-eb6959697653', '908c7ef4-1f18-4991-8f54-0255c5903c29', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('c2b7e95c-95b5-4d16-88de-a3f2f1cb1948', 'b568304d-5197-4cad-8899-cfef305de516', 'from_t_72a', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('c3173f43-67a7-4937-b930-06e0e3e47c0b', 'e9a5e3bd-bf9f-4686-aede-fc389b7eecbc', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('c38d0337-89f8-4ead-9ad6-5f00550f891d', 'f0d1b15c-b43f-4d40-a7a5-91eece4f71d4', 'from_merkava_mk_1', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('c44aeec6-5ed3-49e2-a752-c8ad1575b6ba', '83dd9806-3b2e-4fc7-95d1-62f15d419da9', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('c52dbc17-5b9a-45ab-b2ba-321b85b35ce9', 'eda9d971-8df0-4324-84e4-4d31042202c7', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('c57a989a-078b-4de5-841f-24045663cb27', '0dec896d-5ad9-4a0d-b578-ceaca07dd8e5', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('c5a21984-22b3-4bef-9ada-61b1c1ffa927', 'c30bb45b-a45e-403d-aab0-ac1b4f756039', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '2a7af5a0-bd8b-4715-b849-6aef896a62d6', false),
('c5f4bf4e-db8f-43cd-bc75-e5ae6cbaf034', '4f192a44-70d4-4138-9b8b-14d330ece481', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('c5fda1d5-7f9a-4d38-89ae-d2ebc5ea1b62', '01b1bf69-ae3f-4589-a17d-b555bbd13156', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('c64ebf61-9150-4dee-818b-0c38ec7a6acb', '05b825e4-a538-433c-9a94-19798bfae50c', 'from_lav_150', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('c7cb603e-178f-4ef1-a03a-cb78d1f9b40c', 'e411b2a5-fdec-4dfa-ad79-e15cb07db12c', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('c8f1f359-be0b-482f-b5d8-02029fcfa6fc', 'c1469c1a-c6f9-402d-9883-ce729ff32589', 'from_type_59', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('c8f4935e-801f-4fab-a8a4-0fe757a5a4bc', 'a54227a4-7d45-4195-9473-dac8357c5451', 'legendary_assembly', '传奇车辆组装', 0, '前置车辆和传奇蓝图两项同时满足。', NULL, false),
('ca8c639a-07ae-4f98-b0f7-6743454e1add', '3f0af599-c99f-48e9-aa16-f8f428943d2f', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('cae83182-1570-448e-993b-6dac021c0bea', 'dcb35303-8e69-4119-9984-34373b1c937f', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('cb840be9-cae2-4ce9-99f6-81c6a1d0ba44', 'dfd19646-1786-441c-9ce3-6ee977a17708', 'from_tiran_6', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('cb965d60-f824-4b21-891e-ef7059871d8a', '2e4fcbc8-b8c1-49ec-b82c-d9bbcbf2ac5e', 'from_type_85_iim', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('cbbda585-70eb-4bac-ae03-6509a10c3a7b', 'b7ce8259-b71b-49c9-a45b-9e32aa06352f', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('cc041562-b3fa-4a3b-887b-65275703c1d6', 'a2c06517-ee17-484b-929a-6d0fef07e84b', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('cd08c900-909f-40eb-b249-af881797f142', '0702bd85-b90a-482e-8369-4413f49bb9d9', 'from_pt_85', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('cdbffaf0-73c6-410a-945a-934bbb4ef6a6', '159786d5-1399-4746-8bad-8e7a498d0baf', 'from_tiran_6', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('ce088b7d-6736-4bc1-8802-112d1ec6a5b4', '81835d5b-fde8-4ebd-be1a-9e4ad5c8da57', 'from_leclerc_prototype', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('ce592ac7-1a43-4b1b-9613-07426fc9eac8', '4eb06232-d386-49b6-964e-6b6678dfa6e5', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('cea23ff4-c974-4cf0-9d2c-3618effc255f', '48bb5c5b-6fe5-461c-a1e3-5a6f3057e0e7', 'from_merkava_mk_1', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('cf1c814a-1c59-4ed0-aac8-2423e585c757', 'd77be0fd-25d6-4877-9fef-06fb10cb9953', 'from_t_80u', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('d014d5e9-16dd-40a9-8d19-09d2a19ce911', '8f2b6098-60b1-4986-b368-ac423d812e98', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('d04af0ed-4f27-4756-802f-929aa6eb3f81', '74ed19d6-99ce-4513-9b8f-dadbfc178f14', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('d15debaa-226a-4594-a244-3de634494a0f', 'a6830908-3526-4f1a-ac18-64aa5360c101', 'from_type_85_iim', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('d3c04522-16d0-4072-8238-b72cd5699f83', 'ec8194ac-14c6-4bf2-8b9c-c78804642bf2', 'from_dragoon_300_lfv_90', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('d451484c-4a12-4b0a-a879-0b081c5dc09c', '1456a180-e7b6-4f14-a4d7-e27b85eff6d8', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('d66300e2-4ab4-4dbe-ae0a-0d48038d537b', 'cd341a9f-4549-4bc5-9955-1f9091efaa8a', 'from_type_59', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('d67cd3fa-4a1a-49e2-9b06-01d10726d603', '0117c6f3-ed73-43dd-97bf-5116c07af497', 'into_the_west_level', 'Into the West 活动奖励', 0, NULL, NULL, true),
('d6b21234-2ec2-49dd-aa45-31b73f91cd41', '5988012b-3ec0-4438-a415-c382c85f28cc', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('d6b436d7-30e9-4a47-b636-0197aa697606', '0b33972e-39b1-4e2c-a8f9-2e2c0fbc0163', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('d72175f0-0381-4493-b372-b5ca5af06a89', '665b6553-764e-45dc-8fa9-e056d98db799', 'from_type_79', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('d7336e65-0e6a-46ac-838a-1d4d436aed11', 'c30bb45b-a45e-403d-aab0-ac1b4f756039', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '2a7af5a0-bd8b-4715-b849-6aef896a62d6', true),
('d7812743-260f-4621-9b8d-c00f8d2e3716', 'db399528-31c3-4a51-8e74-c35d02c62dcd', 'from_merkava_mk_2b', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('d7dc6036-ee28-4d00-ab0f-45a7a65c34b5', 'aee06add-8fe1-43a0-ab46-23e76a1eecf6', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('d88a59cb-b3d4-4ae1-b78d-1ea1038101c7', 'ba8a3c6c-ad53-4411-9927-d69f1abf8591', 'from_t92_lt', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('d8bc3ffb-7d67-4998-a891-c4d1d5da0d9d', '6b655414-7cd4-4bbf-b92e-8680fc7bf649', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', 'dee12b40-7ba0-4952-bb75-74d33191ad76', false),
('d9084e2f-ead7-420c-ba9f-8f2a3f8a46b0', '1158b8e1-ad74-4f0a-8c28-7a7dc68fe707', 'from_amx_30b2_brenus', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('d91cb3e7-8082-4527-80d5-f3dce86f441c', '983c0592-11c3-41cc-92b4-d917a3e2b66d', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false)
on conflict ("id") do nothing;
commit;
