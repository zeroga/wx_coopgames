-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."unlock_paths" ("id", "vehicle_id", "slug", "name", "sort_order", "note", "target_upgrade_id", "is_complete")
values
('da510def-500f-45d6-9b9e-c7f4bbfdf5a9', 'd779c971-474f-46bb-b7c5-e057d95bd8ee', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('da79f593-3636-41cc-ae21-2cf3fa887f7c', '17a1f6dd-7f3c-46b4-8b79-0d1e9ccecd52', 'from_merkava_mk_3_barak_zoher', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('db4f490a-9b60-46dc-9ad2-2b3af815336c', 'd9a27da7-41de-45b1-9594-369e899e0618', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('db654968-9f3b-4cd0-93c8-2526d3a92885', 'b553f59c-7b2e-49a5-8682-a0155e9bedee', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('db6bf549-d8ca-4d64-b3bd-26b6be867787', 'fd1bfbd5-deaf-451f-a5e9-071eca73ca17', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('dbd04f3a-20fc-455f-87a2-7624b4107066', 'e37a96bf-a9e0-4acf-bba8-24d6a7817f70', 'from_t_64a_mod_1969', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('dbd90336-665c-46ea-8372-67d71f2bbbb8', 'c2bfdc4f-3489-48c8-ae7f-734f1821ea70', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '5845d560-6fce-4067-aa54-2d774c0a6c3c', true),
('dce26a3b-1c63-4efe-8101-1fa43c5a7d5a', '21f96b13-6122-4c99-9357-9ed8aab9e075', 'from_pt_85', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('df673a90-fd76-4fbc-aff9-900d6b5b84ae', '7c72bb2f-1d0f-45c6-9f3f-b62382f3b779', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('df772005-02f8-4926-b209-67905ea434f2', '90d54748-0c0c-4bc8-9cc2-cbe82f530505', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '0e0befb8-bf42-4753-96fd-17860c7727cf', false),
('df8f31a1-fbb6-44c9-abec-42315de8cb58', '22a86511-0e8f-44a2-a72b-6ede7e2d28fd', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('dfa7e4c0-b719-4bbb-8650-aa113e7f8dbf', 'bee45b8a-f17f-4c36-b730-a552fffd5402', 'from_m113_acav', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('dfe4fa40-824e-4cc3-8680-eae8598d2e2b', '3c5422ac-1584-48d8-901d-fc7bd7d3ef86', 'from_chieftain_900', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('e03de504-5af2-41d8-b553-5dfaf6aab990', '2ee36c95-9495-4e17-a796-55a0e1b0fe5a', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('e1717a80-de16-4ed9-a78e-3593f5d6f73b', '2b2be610-bfd4-4c2a-9329-79fb8789db9e', 'from_t_80', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('e2544a62-ecea-4538-87d4-58348ed6130c', '67fc98d6-3082-44ac-aa2f-1c996c94dc2b', 'legendary_assembly', '传奇车辆组装', 0, '前置车辆和传奇蓝图两项同时满足。', NULL, false),
('e314f7f1-03a8-4262-b1be-eb63c494acf6', 'c45c6557-d3b9-4ca6-9e7e-bb7fbf4eb6ae', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('e413597f-7e88-448f-a4cd-1d77526a1b5f', '4d9d7f75-988b-4fec-9e69-df8ac32c3b67', 'from_challenger_1', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('e44b8a12-c54a-4df9-8e7d-15cfa9bd70f1', '1a424f52-548a-4dd0-9ce7-ba069fbd1330', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '5a3034fb-712e-4171-9104-8c754a4f0987', false),
('e59cca10-3a15-45c8-9bc6-9f3197fcc8f5', 'cc357afd-087c-402a-9ea4-54ffadd547b1', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('e62092b7-a6d0-468b-81eb-e4358449df73', '070a5cce-e20e-4a4c-83a2-bf718e4bad7d', 'from_magach_5', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('e62255fb-d139-4146-a79c-f84601c1126f', '022d55bf-50fb-4251-840e-1ba5e0ab9073', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('e64a1eef-4de8-4e4c-8c1b-7be87708c9ec', '329f42b2-3d6e-4b52-8dfd-e2c0d28820a8', 'from_t_90', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('e756b1f9-e85f-4071-89cd-cbe51549a608', '43fc3700-bb07-46f9-bedc-571845b9c9cb', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('e856a024-397e-49e6-a2f2-231b2f17bd45', 'aeb1240c-71b3-4124-ba09-a9a132460e78', 'from_m50_super_sherman', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('e8a8c354-c569-42d2-b5e4-bc2d3001a336', '3c5422ac-1584-48d8-901d-fc7bd7d3ef86', 'from_2s3_akatsiya', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('e8c1bdf4-671e-43c1-ab83-660a1197a68d', '156e6337-8667-48ee-bc28-73df5821aaad', 'from_fv438_swingfire', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('e8c755d9-d623-440f-b31c-66060fe48df3', '04e13fc8-b08d-43b6-9d12-a8e1fe1c1916', 'from_nm142', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('e92d7319-d674-4060-9946-64527121359b', 'a6ecf548-7b32-4fad-b97e-1c0f9724ed72', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('e9aa1cc3-a9ea-40fa-8c46-128ceb463ebc', '78ab30ec-8613-474f-ad03-d6d9a672b3b2', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('e9c9c4f2-6e27-460b-9d78-62c39ed95a42', '30ec53a9-7666-4cc8-a80c-bbaa84cf2eb8', 'from_t_72_ural', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('ed3f1d97-5b24-41ae-a591-1bd7e56feed7', 'c58630d2-8e21-4263-a299-2b482ad2a20c', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('ed79cb92-2625-4a09-a545-a5ea30a3f91d', 'cdcb5a19-3818-4fdf-a9db-842b12cb06e0', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '39436dd6-e356-41c7-a8f4-104ef84921a7', true),
('ee1afc2a-0f47-464a-aa3a-48d3f5dc86e4', 'a53b6cd6-1256-4b24-9596-79bcfa38b568', 'from_ot_64_cobra', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('ee5437c7-a3ba-4c37-86ee-43848f30abe8', 'a53b6cd6-1256-4b24-9596-79bcfa38b568', 'from_magach_6b_gal_batash', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('f085727c-d0f0-4367-9ac6-92ffce1b7908', '01cb065f-4b06-4121-b2a8-4592d6f417f7', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('f0e0e6de-14da-4ca3-a1fb-67105f4c5dea', 'af94ff25-67fb-446c-81fb-502b4266cd0b', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('f1c089e4-7066-40ec-935c-714fbc8b42c1', '143ba945-f4b8-4e5c-9beb-68f907033e0e', 'from_t_80b', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('f2313288-b00a-4af5-9c6f-1d249243975c', '749f48fc-e226-4e0a-901a-16d428658482', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('f3520066-2915-4a8f-adb0-4a96880e1d2d', '320ca031-6fae-40de-902f-a291e7561fea', 'from_type_96a', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('f48f7ab1-f8f3-4065-a109-43b77a388eba', 'a92e46a7-77f0-42a3-98ea-3949e7ac6ae7', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('f6b38abc-0fed-4a11-9a8b-93038f5a4a4c', '2b2be610-bfd4-4c2a-9329-79fb8789db9e', 'from_t_64a_mod_1976', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('f78be484-a543-4b7a-bde4-0c319f9c4df3', '1a424f52-548a-4dd0-9ce7-ba069fbd1330', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '5a3034fb-712e-4171-9104-8c754a4f0987', true),
('f7df0427-332f-4757-ba65-63f1a1ca3fd0', '03b554a8-61c9-4db8-a137-663b09f4f5aa', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('f895c530-c09c-4e1a-8bf8-d6422cf507f5', 'e56af0e7-50dc-487a-92d5-36685f2d7376', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('f8b37717-9fd5-400a-947e-a7627b30c948', '93bf42fd-74ca-40f3-89ce-e52ede4dce42', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('f9328703-8cb0-4c69-a5be-b5bdc2e931af', '53cdac5e-36b5-4903-b35f-2d9007897084', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('f9741bc6-b25f-41ef-aaf6-ae18e55bb4e6', 'f0ce22de-c6b7-44cc-8274-eab645e4e293', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('f976487c-3c38-4ada-8b97-6d967d1d8a68', '8e5a36b9-924b-4812-b200-db7bade015ed', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('f9b4ea39-d6f7-48f8-901e-dca3a3a379da', '530eff10-ae81-493c-a250-6fed34ea6ead', 'from_fv101_scorpion', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false)
on conflict ("id") do nothing;
commit;
