-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."ammo_upgrade_links" ("ammo_id", "weapon_id", "vehicle_id", "upgrade_id")
values
('ef4b44dd-0e3f-460c-b2e1-4c1345ae3103', '90f06721-b286-4319-9c8a-56eb833fd4a0', '8c3b833c-da75-44d4-a54b-9426cd3f94cc', '28497b3b-bea6-4a8e-bc04-23fc264ca624'),
('f06b382b-cfa2-496c-ab64-1d142b6bc34e', 'bb9fd65d-a448-438b-a1a9-cf1910f383c6', '8712c68d-7ea6-4d7e-a2dd-829dee0d2b32', 'bfa7834b-a1d3-449a-a5a2-c3e8c847ca59'),
('f1ec98b8-0428-410c-9cba-7eb04be9bb0e', '0b818448-b100-4ea9-99ab-a305c38864a9', '963743d9-6404-4cd7-9ea0-7ef2e215d29b', '17293365-84de-4640-9cd9-d182070b4319'),
('f61bed44-3689-4928-94b2-c63bbd05e33e', 'c8109019-2a97-4bdd-95dc-43743e12856c', 'd779c971-474f-46bb-b7c5-e057d95bd8ee', 'd5b16f46-4de1-42b0-9b85-553bac157743'),
('f65f84f5-8706-46e3-a7cb-2d1d42296148', 'b7632e63-6ae0-4d1c-8e21-37df36fb6ee7', '54d54f83-81d6-4ea9-8826-f47d4a061e9d', '23d50166-51b1-4f47-bb83-9e6b226f49bb'),
('f67c4f0e-e0b8-4277-af16-17184db41ede', '7c98f107-c2ef-4c31-8fef-a8fb1507bbba', '52324ba1-ee4b-4d2d-9693-a68c1c19064b', '16bf21a4-e084-421c-97d4-b78688d48878'),
('f6fe11e0-ff32-4fc2-b651-1e51bc2fe345', '90e87839-2b2a-4210-94c8-c47a0e0a5a36', '829a8732-4d9f-4103-bbe6-71e3a1f9a369', 'df1fe2cb-a010-44f3-9386-68e654e7b19f'),
('f7aff2b4-67a1-4e8e-a6e7-477db364acb5', '11e19aae-917c-4f46-ae8b-20241d77ee89', '4a63fa8e-983b-4c5e-b477-3fd39845f1f9', '41835aae-a3b7-4954-994b-b3743868f44b'),
('f94e268e-238d-452d-b74b-cb3209e22d51', '1a15c457-d48e-42cc-bb7e-53ae94481050', '0702bd85-b90a-482e-8369-4413f49bb9d9', 'dbbef73f-0a14-4165-ada0-47ccff97db65'),
('fb464797-d5cc-4860-b96d-1f3e109b6bf1', '0c93ac37-cf94-4fbe-af51-c2100b4af5d0', 'e4fa63e9-935c-4e80-9b1c-d5d0fee24536', '80b0f21b-7631-4c12-a430-ecca8ccf6c31'),
('fd07e69a-f8f8-4df0-860d-282e478170b1', 'a3e054d8-df22-46b0-a9bd-96c734187512', '04e13fc8-b08d-43b6-9d12-a8e1fe1c1916', 'e1135d87-e3f8-4aa0-b45f-2e68ff059545'),
('fdfccab3-8bc7-4bd3-b13c-8eb5593253ab', 'c9ece41e-32e8-48fc-a409-826159106a3f', 'c1469c1a-c6f9-402d-9883-ce729ff32589', 'd5c819ff-a0ef-4b5f-8bb6-47bdc5e6490a'),
('ff829728-e036-45b4-8e9b-9c3b749ef2d2', 'b966f114-b671-459c-be2e-56d327d70f89', '9ed6086a-db40-4e62-9de0-e79075558a64', '17955c3f-1725-4c88-88e7-ef0a1d5d34de')
on conflict ("ammo_id", "upgrade_id") do nothing;
commit;
