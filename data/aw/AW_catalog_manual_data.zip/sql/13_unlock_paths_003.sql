-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."unlock_paths" ("id", "vehicle_id", "slug", "name", "sort_order", "note", "target_upgrade_id", "is_complete")
values
('4b94a3fe-d6cb-4ffd-bb55-7b352fb61f8c', 'f1428c19-14a5-4e70-9296-d49073149287', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '0bfd4474-c5ac-4e9d-9c89-48bf7274bb66', true),
('4ba96cb4-49f1-4619-99dd-93f19aebe26e', '7ac619ee-3805-40b0-8018-606dc01c7344', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('4bf87ce4-fe2b-4746-b099-caa511340f12', 'ea726dad-7d37-4525-a8d8-bd0ab9e1eb23', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('4c38c871-4513-4ef3-8ba1-d939b8eaaa62', 'b04c1fa3-d67f-4f85-9719-c4bc5b724fe3', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('4c490c29-77e0-431d-9b55-6c83f7f9c082', 'f1428c19-14a5-4e70-9296-d49073149287', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('4cb916f7-a3cb-4b88-aec4-9edcf1fdb590', '4191f488-bcdb-4945-b2bd-2b47160d3c2f', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('4e5f47d6-f7f8-4692-8e57-2b33da2abf79', '1e429df2-c669-4844-9a50-beef34a81d9e', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('4eca6962-b070-4489-819f-4e9a820b3118', '5ee222ba-5532-4796-95e5-eabf96efd5e0', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '98875bab-0173-48a5-8e92-36c87932f542', true),
('4f598c33-e832-4dfa-9325-f20c049a7fe3', '963743d9-6404-4cd7-9ea0-7ef2e215d29b', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('4fb17015-6a11-4dc9-89fc-7e4f32e42774', '471947c2-ca67-45bd-adb3-34243b42f5f4', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('512a23b7-2673-4c13-bf48-00183107f36e', 'a8c2e49b-342e-4c18-bfee-11e57efa03a5', 'from_lav_600', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('51cd9141-1a41-40ce-9233-071f14ed7d62', '3c888cc5-fe24-41d2-9416-a44f4e159108', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('527f85df-dc1e-4086-8397-6e00e298ff73', '518b602c-3811-449a-b6e0-32cbe0904f39', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('52d0afa1-5384-4566-8df7-4f70307a2eb6', '82166dc2-b0bf-4d11-9a0b-1eb34c65149d', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('52f543a4-7d74-4fb8-bb76-cfcec07d83d1', 'c10a3b38-127d-4e3c-b19c-e1fe73cfbecf', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('5377d615-0946-4ef9-8dfc-8eb5a03d5c12', 'b568304d-5197-4cad-8899-cfef305de516', 'from_leopard_1a5', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('5423abda-76a8-469e-bb76-99650e5da4da', 'c2bfdc4f-3489-48c8-ae7f-734f1821ea70', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '5845d560-6fce-4067-aa54-2d774c0a6c3c', false),
('561e3ff1-bd71-4862-8b22-92eba98a3557', 'f45674ca-ff9b-417a-b62a-0916e407aeaf', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('564a3cfd-cdff-4fcb-b63f-c27853dc0655', 'f0d1b15c-b43f-4d40-a7a5-91eece4f71d4', 'from_m60a2_starship', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('56a7f185-d20e-4fe2-bc0a-a46ba72dee03', '798c4f70-6e3e-420f-939c-45288041ba0e', 'from_t_90', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('584b37f4-c611-44fd-b4c4-dbe3d45a90a9', '04e2d20d-122d-4433-8b36-bb1c859b9e85', 'from_m60a1_patton', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('584d3b39-fafd-4370-a993-4f732b7383c3', '1d9557cc-94ce-4027-9350-01f74b97aa06', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('590d6530-d075-49f3-8aaa-350d4b274d3f', 'a743b862-efb5-4ef4-b9ab-56684dddae14', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('59d51631-7618-4120-8be2-20ef4f2e551c', 'a3b36f70-bf61-4744-a282-6f14fbd32151', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('5b31767b-746a-464e-b8ca-7bf0b6b6afd4', 'e40f8587-d869-444f-9d08-e54bd97049eb', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('5bdb4c8c-bcf7-4962-a650-9b9d5c122353', '8e631852-d05b-448b-8093-99c8182b1202', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('5dbfe50c-e4d9-4df3-ac2c-0dcede759c34', '458043b1-7aeb-43d9-be91-5f1d09824b9a', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '8103ae0f-4491-4f92-b1c2-10296930c70b', true),
('5fc09f20-1e8e-48e2-ae53-a4727970d186', 'c5e769bf-5216-4acf-9cfd-6444ad3c1461', 'from_harimau', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('61c51dc2-f3b6-4aff-9e5f-13f428662cef', '5068b368-4237-4058-80cd-04a88a2870d9', 'into_the_west_level', 'Into the West 活动奖励', 0, NULL, NULL, true),
('6345ff73-4ea1-428c-ae0c-2e8184f6e469', 'bf401b26-ba15-4bc6-8f10-861ecc6b4083', 'from_lav_300', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('64183fa7-3332-42f5-bfac-24c67b51e59e', 'fb5f8035-4e26-46bd-8750-3a41133a638c', 'from_bvp_m2_skcz_sakal', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('649885fc-3263-40eb-b4ad-c86322082987', '796a243c-8bbb-4607-9c29-a5f786d6ffa9', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('64dc9be9-9e7c-405a-b86a-243d85e8c8d7', '576de184-9de2-42ab-8a85-2bd82b493568', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('656f40fd-b337-4097-86c4-a5f271ad9b5f', 'd77be0fd-25d6-4877-9fef-06fb10cb9953', 'from_t_72b', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('66b40fbd-e964-4cc3-885b-aa470af17469', '458043b1-7aeb-43d9-be91-5f1d09824b9a', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '8103ae0f-4491-4f92-b1c2-10296930c70b', false),
('68afacda-3126-4c75-aac5-a3d5d98793be', '30d8209e-b48f-4131-9547-8fd71dded811', 'from_t249_vigilante', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('691915fb-3ee0-4820-9461-6c5a95e2239c', 'e200da9b-1d1a-42df-9595-35178da0e953', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('69220522-bde5-41e5-aa6a-b9fd95f66507', 'ffe5895b-441b-4ac5-a6f4-ca2266dd2fee', 'from_fv101_scorpion', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('694bf502-9370-45be-9d78-73a43022697c', '8ec97761-38c0-44f9-b34c-f227e0ad3cfc', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('6979f012-0503-4664-af9a-8cceef8008d0', 'cdcb5a19-3818-4fdf-a9db-842b12cb06e0', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '39436dd6-e356-41c7-a8f4-104ef84921a7', false),
('6b80b514-8758-4268-b796-6c8690265f14', '642cef03-079e-4cde-8389-9b3ac213abdb', 'from_vbl', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('6bd2e85f-2715-4442-99c1-208a0f8d07a7', 'e857f286-f531-48de-914c-26d4594cd177', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '12c53576-12f7-4d9c-801a-be51b795e1c6', false),
('6c3b2e72-f5ec-49d4-bec3-840c691537e0', '64b724ba-6d8c-4b2b-8de8-31baa6533e99', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('6c9e19e9-5091-4fa6-b899-14c0a6624add', '196f3091-ce59-4fec-b334-3b359f797468', 'from_bmp_3m', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('6cb59bfd-7058-47cc-ae93-7cc5e51e03c9', '06152f97-d298-4fc0-90de-37f9e0922601', 'from_m1a1_abrams', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('6e1b09f6-9de5-4f7d-91dd-d6b1797af109', 'f07ee32c-b5f0-4735-8073-7400492088f3', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('6e5a730e-c759-4e57-8a9b-95f1394a1bd8', 'db399528-31c3-4a51-8e74-c35d02c62dcd', 'from_magach_7c', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('6e7cef82-19f1-439d-ba93-625187a5f131', '713cc161-f358-475f-a1aa-e75c87edd776', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('6f05cadc-8ffe-4f77-a025-c219ff4409bd', '54d54f83-81d6-4ea9-8826-f47d4a061e9d', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('70beb74e-46dc-47b8-bf65-38da5ee3c6db', '4baeb2e0-ab19-433b-8115-b446513a3d43', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false)
on conflict ("id") do nothing;
commit;
