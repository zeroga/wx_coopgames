-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."unlock_paths" ("id", "vehicle_id", "slug", "name", "sort_order", "note", "target_upgrade_id", "is_complete")
values
('28218c0c-6dd9-496c-879c-c8f14eeba890', '642cef03-079e-4cde-8389-9b3ac213abdb', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '25c3167e-cab2-4c46-b6ab-d173ab6a40af', false),
('28262fa8-bd2d-4e46-a063-3473687c5c71', '5b1cc303-fa43-43fa-8ab5-10fecc7d3a8e', 'from_m551_sheridan', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('2862f51b-922b-4ff9-9927-e68c7a20a9ec', 'aec6d424-66c4-4b5a-b449-f9d65bc4c9bb', 'from_t_64a_mod_1969', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('28635900-2e47-4b44-a497-d67002584cac', 'c4b4d450-eae1-4596-8eb8-5dc9b34f8a68', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('29f16bfd-855b-4a88-8918-ef1516664f0e', '25fc7da2-a08b-4463-a4f6-66f4675e01ac', 'from_m551_sheridan', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('2a10e9fb-361d-4f78-a02c-4f552910529f', 'e920baf9-ca92-4da6-9160-97f4886d06e2', 'from_type_90_ii', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('2b646335-2ec3-4283-a17d-c2da41d2c948', 'e4fa63e9-935c-4e80-9b1c-d5d0fee24536', 'from_type_90_ii', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('2bb93adb-f747-461c-8b8a-ae48af4968a0', '0085a91b-7acc-4842-a0dd-09c8c0100bf3', 'from_fv107_scimitar', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('2c93919c-2d5e-4efc-b0b3-c67a20c19939', 'a71748b3-121e-49f7-8cb0-2f1e0f2e87a3', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, 'b172acfb-7fb8-4ede-b64d-2a25300e3956', true),
('2cd583a2-1e3a-4649-8407-1966f89b600b', '36ca60fc-6fe2-447f-8595-39dd7b1fefc4', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', 'ed87157d-3fa1-4407-a324-1452d8d7fb3c', false),
('2d66a7cf-8f0c-42ef-9a12-e7e69b9ba528', 'c1d6d061-4dc1-4292-ab18-3e5b4e7b4fbc', 'from_t_80bvm', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('2f89344e-d86b-4020-bcb3-f62074058e83', 'd2e553b3-fab4-42d9-a490-cbc681fec7e8', 'from_stingray', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('3260414c-1214-48ed-8453-56a4183f6068', '2dd6d082-dcc8-45cf-88d2-4e220c4a3550', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('327834d3-fc3a-45b4-80cd-205d7e699041', 'f831cd63-3565-412b-a121-0829508c946a', 'from_m109', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('35bdff01-0ec5-4ec0-9ca8-dcf431707ef8', '530eff10-ae81-493c-a250-6fed34ea6ead', 'from_sho_t_kal_dalet', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('360bb679-b88e-445a-9a9c-66bc1a30c82d', '0f51ebf2-266e-412f-ae07-2d2a25412d07', 'from_wiesel_1_tow', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('365122d9-2e8a-46b5-b401-658f406b4c6a', '2be295a8-7495-4a89-a4c6-efca811938d3', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('36def867-53a6-4c67-bdbd-a7f3a2589b0a', 'ececbd6c-5cf9-4f1a-9562-e1d138e0fdb3', 'from_as21_redback', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('37ffe10e-2b08-4c08-94ee-cbe8d08e1760', '2c834006-73a0-4287-8f9a-22d393ae4bcb', 'from_t92_lt', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('380e434a-1f41-44ab-ae04-2f0058594028', '3371ac91-7a05-4b7c-be05-1a9f1e3f559e', 'from_merkava_mk_4', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('386e0914-69a6-4cd2-a914-8afe55d33fc0', '745282a9-c687-46cc-96a6-fa36b0c67053', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '3ac9ef2a-721a-42f3-8ecf-c73561ec5c5a', false),
('39948a2f-6d46-403b-99f3-c9d1c3533764', '2b6f20a4-552b-40c0-80f1-69ea78bfbc4d', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('39ced718-9404-46a9-868c-1632f889c4c4', '25175371-5e60-42d6-8360-4042101a8f2b', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('3b01e82e-8c1b-400e-b985-1977e953258f', '9f699577-8c85-4092-9809-e7871000f159', 'from_palmaria', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('3b197426-06bd-4baf-b997-3fe7ed5a7b88', 'a50a4098-8f3f-48ca-b46c-1159f9137c51', 'from_2s25_sprut_sd', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('3b5d868f-fe5e-4908-a4a2-fa1222c4d4e5', 'bf401b26-ba15-4bc6-8f10-861ecc6b4083', 'from_leopard_1a5', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('3bf5a3a6-5022-4d5d-b003-bebf55817d48', '6138e381-07bb-4802-913d-e139628d318a', 'from_t_62', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('3cee4956-84b3-4e60-b4c5-43cbf486e3d7', 'c0a5e37d-eb17-474b-b0a5-3dacf90f8eba', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('3d6f3d55-9f84-482a-a8d6-de3370fcb6a8', '6407c9ee-f005-4b97-a3c1-f255e1a53aab', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('3dc697da-f472-4f15-96ef-ac7ad9a0f2cb', 'c2f3f80b-48d0-49d3-80c1-96f6ede5b436', 'from_vcac_mephisto', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('3f125096-0c0f-4c10-a671-5b627e14eb91', 'ececbd6c-5cf9-4f1a-9562-e1d138e0fdb3', 'from_k_153c_raybolt', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('404cca73-3a5d-445a-8e72-860c39a209ae', 'dc09fc11-93f0-408c-96d7-f065aaf098c6', 'from_m1a2_abrams', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('4103fd09-31bc-4a93-8a11-f4b1307787b5', 'c14d4a00-3e02-4a41-8ecd-1b0410f8146b', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('412a49a5-7796-4d14-a36a-7d92898139a7', '5a5db794-836b-4889-abb4-7aaffb44109d', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('413f82ae-b2cc-4e9f-b56f-3ddb576f3b1a', '32ff9a17-d0cb-40d2-b2c5-8d1ae9b40cae', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('4273ed6d-5928-41e3-8594-62a79a8158dc', '90d54748-0c0c-4bc8-9cc2-cbe82f530505', 'from_fv510_warrior_milan', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('42c1f9de-43e2-474a-a4bf-a2a6bdd50e76', 'f8f72ef5-71ae-497f-a1f8-87a5f8f9f45d', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('42fba73d-35b5-4a4e-a56d-4d33f4d981ce', 'a6b18b44-cfcf-4bfb-a9f2-abfc2020ab90', 'from_m1a1_abrams', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('43dc9199-afe1-4b2f-8f3c-766002719d65', '90d54748-0c0c-4bc8-9cc2-cbe82f530505', 'from_b1_centauro_105', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('446121de-81b8-4606-8e27-d197009de70a', '7d5272b6-30b7-472d-abf9-7e8d036393f4', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('452f363e-1582-4282-9694-e7c98c814eba', '1737a099-ff4e-4a9a-8543-738064f46966', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('4547670f-ed11-48b4-b277-829ffff26582', '33db173e-f6bc-440a-9641-2ad5cb83ecfc', 'from_lav_150', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('46dad5e2-f9c7-4279-846f-2cacf19ecdee', '665b6553-764e-45dc-8fa9-e056d98db799', 'from_type_80_ii', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('48a38d8f-f8bc-4797-ac59-ded600005ed7', 'c4896c68-75f9-45cb-bc2e-af967a32dcca', 'from_c13_tua', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('48db2c14-1282-4b90-b98f-766d8562f350', '6b655414-7cd4-4bbf-b92e-8680fc7bf649', 'from_fv721_fox', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('495b9da5-a642-4287-8a14-95007af45325', '5d4bb49c-885b-4741-a7ca-f53176644d5d', 'from_bmd_4', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('4a07ed88-22e4-4659-947f-b1380eb47dd8', 'e4fa63e9-935c-4e80-9b1c-d5d0fee24536', 'from_c13_tua', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('4a89ca05-b856-49b1-839d-9113f9de064d', 'ec644f7a-f990-4884-a0b2-60a92c87c518', 'from_amx_40', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('4ad5aa3d-707c-4f45-96c1-e7e4a8a832e2', '8f69afa8-1528-4a46-a81e-00fe580bfaa0', 'into_the_west_level', 'Into the West 活动奖励', 0, NULL, NULL, true),
('4af9e8ab-f933-4e6d-bfa2-a4bcc1427af4', '66964cf1-bfba-42ec-9f93-7998c33db913', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false)
on conflict ("id") do nothing;
commit;
