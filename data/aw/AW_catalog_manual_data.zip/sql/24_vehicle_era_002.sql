-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."vehicle_era" ("capability_id", "era_name", "era_type", "generation", "layer_count", "is_special", "ap_reduction_pct", "heat_reduction_pct")
values
('c8be640e-570e-4d11-b1a7-ef9eee958b55', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('cc471bab-2571-42c4-bda9-29e6f5d65015', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('cecdabb3-ac48-4cd0-be36-9027c624b48e', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('d2900a10-fa01-4b4b-af4f-c527650d9655', 'Engine Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('f0d199d6-1abe-4b9d-ae19-576db2c534d0', 'Engine Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('f2c60c8b-a38d-46bc-bfff-0383e8279588', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('f38ccf54-8269-4a1b-a0a5-209642f1ddc8', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('f3a9fc7b-39a5-4800-9c63-f6074b58b19c', 'ROMOR-A ERA Kit for Light Vehicles (Gen 2)', NULL, 2, NULL, NULL, NULL, NULL),
('f3ca0dbd-e978-44a8-a8d1-51f6f5e330a0', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
on conflict ("capability_id") do nothing;
commit;
