-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."unlock_paths" ("id", "vehicle_id", "slug", "name", "sort_order", "note", "target_upgrade_id", "is_complete")
values
('7146b999-2f46-43d3-8a4e-bac28a824cca', '6b4e302d-20cc-428d-a4b7-119f13dfd495', 'from_oa_82_jarmila_2', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('7468d60e-a83c-4954-b316-ad209c456e81', '9f699577-8c85-4092-9809-e7871000f159', 'from_plz_89', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('769d2106-7ab8-4131-98e7-6b929cf41307', '36ca60fc-6fe2-447f-8595-39dd7b1fefc4', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('76e42bf1-a2cc-4c79-8b2c-4b7077fb3f2e', '69efb3c3-aa0e-46c7-a60a-d26d8db40c22', 'from_stingray_2', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('77098bd6-f512-465b-b3d8-013d88181bc2', 'f48a7fde-4f8f-4518-88f0-cb3eb95dafbf', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('776c2057-f2f9-4dbe-9c06-dac8221fae5d', 'd52cab15-129b-4636-8134-af9496055dcb', 'from_type_16_mcv', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('77905a77-0fc8-4b0b-9275-31409225032b', 'c93574ef-f883-46c8-a142-64b2a25f9d76', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('792dd0f7-c771-478a-b5ea-ae7f13b89e9c', 'fba245c5-5198-4bdb-a883-0e9424cc0e77', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('79c62357-d27c-4694-a5d4-4f4f609a218c', '5c8b4a7e-d01d-4d6e-9808-a57a11f8048c', 'from_bmp_2', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('7a4b9cf9-e57f-428c-bba7-68aa1172f687', '903201b5-8dff-4ed6-8fbd-ce3e114dcfd5', 'from_m41_walker_bulldog', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('7aacb322-22cf-4ca0-b5ab-31b05312f993', '8571dd56-9d6b-47e9-966d-e53bf84c286a', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('7cd770ec-f38f-437d-9882-0b36298d657e', 'e9dd38ea-be69-44ed-b405-8c50562d48e8', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('7d80f8ed-7688-42c2-a12e-6cdb458a38df', '0955f9b8-d76c-4f59-845e-fc5150ea0604', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('7df2047c-6181-4ce2-879b-e8ac1feb2d9c', '2ff6812c-aed1-4818-84ee-cc72864c50e1', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('7e1390b8-9691-48f2-9258-ca54b0d889a2', '829a8732-4d9f-4103-bbe6-71e3a1f9a369', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('7e72192a-df43-451c-97b3-f306d0777838', '55ddf0f5-9a2f-4f91-b068-ecf209043dd8', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('7ecebb61-8dd8-4600-9086-63218987e35f', '4fbd409d-a69b-43c4-979f-4f91eb43c827', 'from_type_96', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('7f37582e-02a0-460a-8f84-8b072626202c', '91afa5b6-8626-4fb9-9a56-ad48c05f8cbf', 'from_tiran_6', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('807b2c9b-7db5-47fb-8445-042469ec0bb6', '8e5c6dd8-cf32-4543-a979-ec7b387a0553', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('824b5b21-005e-4181-a447-bbd7a082979b', '6af4fa3e-c75f-4a87-855b-304efc487377', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('834ba851-d1bf-4403-bd45-dae4353bbe13', '6b4e302d-20cc-428d-a4b7-119f13dfd495', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '67d76f84-a1e6-4b83-98d7-824c7524276f', false),
('83c71848-6a15-42d8-bd36-14105b31e16c', '707677a2-9f94-44ab-a91c-64c86698636b', 'from_sho_t_kal_dalet', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('83e4aff2-3410-48f1-a03e-c1b5b26297c1', '5ee222ba-5532-4796-95e5-eabf96efd5e0', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '98875bab-0173-48a5-8e92-36c87932f542', false),
('83f14a8c-1959-4512-bb8d-688ffa09ecc4', 'bf6b9d3b-42cf-4da7-a1f7-4f141971427f', 'dealer_token', '10级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('84932251-9a40-43f0-9ef7-54b5d211e259', '9ed6086a-db40-4e62-9de0-e79075558a64', 'from_sho_t_kal_dalet', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('85396a3d-e4b3-4c5e-8f98-d07a94e49ec8', '5c31d3d4-092e-43f5-baa8-ddddee3faebe', 'from_m108', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('85b6ec5f-8df5-4506-8230-8e8ca8d1a35a', 'bee45b8a-f17f-4c36-b730-a552fffd5402', 'from_dragoon_300_lfv_90', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('861dae9e-889c-4c20-b359-e53f27ac7ad8', '74e66f8f-b3b6-4cc4-bcab-80140bba7d01', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('86885069-baa5-4f9b-8c94-1388683a0cb9', 'ccdcafe2-d14a-4a09-b050-b8d4ccfc9dce', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('86920c15-afe7-4099-9f62-4cc00b6faa89', '6f907880-6281-41f2-9ed8-dbb6250ad6d8', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('8766369c-b7af-449b-9a96-d50f0a5af4dc', 'a8c2e49b-342e-4c18-bfee-11e57efa03a5', 'from_palmaria', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('89154eea-e1fa-4732-a60b-2dd21283ee5f', '5d4bb49c-885b-4741-a7ca-f53176644d5d', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '19ba320c-19a2-44ec-84e9-278f3332db2f', false),
('8a0cc8d1-6fa4-45ea-8109-3982a9623716', 'dcd94ade-0f3c-4199-83d3-4a222f6ed96b', 'from_amx_30b2_brenus', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('8af3a670-6623-4801-8d08-14643f1f1064', '745282a9-c687-46cc-96a6-fa36b0c67053', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '3ac9ef2a-721a-42f3-8ecf-c73561ec5c5a', true),
('8b96edfd-85ab-45e3-9250-4a4d435292b8', '90d54748-0c0c-4bc8-9cc2-cbe82f530505', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '0e0befb8-bf42-4753-96fd-17860c7727cf', true),
('8bd603a1-616a-444a-8c8e-4a8d46feafed', '8704cf4e-e64f-4d84-8aba-574a7a4acaf3', 'from_bmp_1', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('8c5f005d-f4c8-4803-a76a-506c0d68dd7c', '0c4d952f-18f1-4ea4-b6d7-e472ce5189be', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('8e0556c1-05eb-49e1-b7b5-310081c114bd', 'e573091a-a953-4be1-8498-c9b51a143806', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('91085f6b-cc8e-44de-abd4-515fc7c0f766', '1d34ea58-3895-4425-a90c-465050dea391', 'from_leclerc_prototype', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('91cbc204-2e43-4865-9bb3-77edc7f0714e', '19e4cb29-9bd4-422e-ac4a-d2242afdf45f', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('91d0d67e-796f-40fc-b175-dcc36d5114c3', '1f632f00-00e4-4990-bc32-2ea58f73570c', 'from_amx_50', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('925ee562-d723-4e9e-a7c3-f52737fce7f0', 'e3f0225a-aae7-4064-89f0-8aba2b574db8', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '74a2d02e-b8a6-4d42-b03d-3d95d528af94', true),
('92ea21c6-79d7-41da-b63c-627d5467cc7b', 'd9c55e1a-64d0-4350-8dd6-d5b988ca99d9', 'from_t_80um_1_bars', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('931c90b6-4cb1-4e96-b26a-02b61bf41a1a', '58a77d8e-fd4d-47e9-95e3-ee642d616ba9', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('952fadf6-78e2-4407-8597-b85394a18b4c', '13c0889b-8a30-466f-95f6-f34b242d3c60', 'from_fv510_warrior_milan', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('95d18c3d-9ed6-4958-bd63-9a2d84932f31', 'f0d1b15c-b43f-4d40-a7a5-91eece4f71d4', 'from_m60a3_patton', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('95e3a8d0-d049-4fb4-a618-d12199b6fd74', '8e3128ad-9fd3-4fc2-a763-9d15e9df3a70', 'from_9910', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('964f3054-5f01-4304-a634-a9e55bd2c2c7', '6b655414-7cd4-4bbf-b92e-8680fc7bf649', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, 'dee12b40-7ba0-4952-bb75-74d33191ad76', true),
('97bceea6-22fc-4d67-adb6-ae1f002c8d29', '9e6b1b23-2c37-4e46-9b8b-a20934fd9a64', 'from_2s3_akatsiya', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('97eb57d1-536a-47c1-8e2a-e491d2e5e2ab', 'a4970f88-8ee6-47fc-a4fc-8ac213277c5f', 'from_m48_patton', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false)
on conflict ("id") do nothing;
commit;
