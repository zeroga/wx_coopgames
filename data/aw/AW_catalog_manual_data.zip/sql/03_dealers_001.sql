-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."dealers" ("id", "slug", "name", "sort_order", "source_url")
values
('4d6b76a3-fb47-4b7a-be66-3f2412b5aad7', 'oscar_faraday', 'Oscar Faraday', 4, 'https://armoredwarfare.fandom.com/wiki/Oscar_Faraday'),
('7ac40e75-568d-4fdc-bf3b-625fa244e73f', 'francine_de_laroche', 'Francine De Laroche', 6, 'https://armoredwarfare.fandom.com/wiki/Francine_De_Laroche'),
('8548348f-6cdb-4f80-b0f6-d007c079968d', 'marat_shishkin', 'Marat Shishkin', 2, 'https://armoredwarfare.fandom.com/wiki/Marat_Shishkin'),
('9ee55093-f9e1-4830-a076-4fcafa747dfb', 'sol_schreiber', 'Sol Schreiber', 5, 'https://armoredwarfare.fandom.com/wiki/Sol_Schreiber'),
('bdde29a9-ac1d-405d-8ec6-7b961c22fc4a', 'zhang_feng', 'Zhang Feng', 3, 'https://armoredwarfare.fandom.com/wiki/Zhang_Feng'),
('bfc3cdeb-9bc9-46cb-ac6a-c36108f7b101', 'sophie_wolfli', 'Sophie Wölfli', 1, 'https://armoredwarfare.fandom.com/wiki/Sophie_W%C3%B6lfli')
on conflict ("id") do nothing;
commit;
