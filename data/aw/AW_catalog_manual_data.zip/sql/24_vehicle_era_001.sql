-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."vehicle_era" ("capability_id", "era_name", "era_type", "generation", "layer_count", "is_special", "ap_reduction_pct", "heat_reduction_pct")
values
('000a2191-2a96-4f3c-8516-f80255f6b366', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('04562861-2361-422b-963a-e820a091feb4', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('086e4151-4fca-42c0-84ff-868a7a5f092b', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('09554e7a-f637-42ea-8b5a-766a68123faf', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('0a5e94be-1d12-4aaa-b6b4-7f83e14806c3', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('1067edf9-1514-47b9-9eea-0535316f2c96', 'Upgraded Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('128a2d8b-b2b2-49e7-8141-49aa60a3969a', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('16e73186-d39f-41d5-a3ee-b252391fc78f', 'Engine Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('19a6565b-6d11-4f18-89a1-13e6f2ceb92d', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('1a5b23ea-100d-4a71-b58e-8c3d664a29e3', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('1af6a4d1-d959-4785-83ec-17447c235d6d', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('1e38274f-ff0e-47dd-bef6-dceee86e74ae', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('27b8faaa-20e6-493e-8cbe-b8d75c0d7058', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('2a56d330-24d2-4f0b-93b2-52cbff4a97fc', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('2e6e0051-1531-4f9e-ab92-8b88ec8f7b21', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('31605480-d35f-49da-9555-7df73464b463', 'Engine Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('35a11af2-3bc0-4d94-a220-51eb4bb98ecf', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('37632f7f-d646-4ec9-a376-36e2919c5c6e', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3cfbd682-ab79-434e-9fe1-4ad453a6809b', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('3f14a03d-a567-4a26-a3df-3ee493d40949', 'Malakhit', 'Malakhit', 4, NULL, NULL, NULL, NULL),
('428d6b67-21b4-46cb-8845-8eabda613661', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('458ed166-8a68-47a6-a929-9fb709223579', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('59007dde-55b5-4d52-802b-2ef066c8412d', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('5ce4eb2b-e495-495b-b50e-7aec6fd8bdc3', 'Engine Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('5e7f879e-7b6a-4839-9bb1-75ac19b3811f', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('60585507-df9d-44ac-9f04-aebec4285673', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('64732124-e2bd-4b99-a30c-80b4bcd4dd61', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('6780aba4-f1da-4ab8-8684-d2abf8ebf805', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('6d9f39bc-3c94-44c7-ac58-f71b72c84e49', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('6f62231e-6cfc-489c-87f0-4d9e6ce4e839', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('707b5c37-280d-4aac-92ae-a50ace948dae', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('744f4c5b-4715-4ee6-8259-cb69187bbb77', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('7b7ca621-5968-4ebf-a0d1-2ae5243ec1f6', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('8247df62-ae72-4b24-addf-ffba106bf66b', 'Kontakt-1 Explosive Reactive Armor Set', NULL, NULL, NULL, NULL, NULL, NULL),
('8ba9f21d-0bf1-4c1c-b7bc-3e91f8b4a76d', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('8d517e8c-7daf-4389-8457-d18c8b13b8cc', 'Engine Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('90a44b8d-33db-449a-b205-89905bf9a65d', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('92ae01e1-4f46-4712-abbc-53c096f94781', 'Karkas-2 ERA Kit (Gen 2)', NULL, 2, NULL, NULL, NULL, NULL),
('9b729823-f16f-45cc-9e96-553a2ce98516', 'Malakhit', 'Malakhit', 4, NULL, NULL, NULL, NULL),
('9d66eb8f-cdb0-4050-994f-020f2ee43aab', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('9dd470ed-2771-4b00-bb21-094aa97cd021', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('9e5daa47-897e-4484-8939-9733c1360481', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('a2124788-f112-4ad8-a1b7-3f336b3215a4', 'Improved Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('a634f651-8eb7-47c3-aefa-7ae8ff20f9b9', 'Engine Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('a63f0de5-a264-497c-854a-67d90f8799b0', 'M60A1 Armor with ERA', NULL, NULL, NULL, NULL, NULL, NULL),
('aa013ec5-331b-4103-9c56-32f6de0c8552', 'Improved Autoloader (General Reloading Improvements)', NULL, NULL, NULL, NULL, NULL, NULL),
('b8b7f2bf-22aa-46ca-bcfc-438c3eeb147a', 'Upgraded Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('b9e47dbf-086d-4093-9111-ea097cb4dde3', 'Engine Exhaust Smoke Generator', NULL, NULL, NULL, NULL, NULL, NULL),
('be053d79-1c6f-488d-bccf-658d497de2b0', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('c10678cf-f333-4044-a2e0-bf08665e4cb8', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
on conflict ("capability_id") do nothing;
commit;
