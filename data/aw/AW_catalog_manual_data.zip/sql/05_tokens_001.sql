-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."tokens" ("id", "code", "name", "dealer_id", "tier", "source_url", "source_type")
values
('255bbe11-9381-49d2-92fe-66d9ffb776c9', 'zhang_feng_t9', 'zhang feng t9 Unlock Token', 'bdde29a9-ac1d-405d-8ec6-7b961c22fc4a', 9, 'https://armoredwarfare.fandom.com/wiki/Type_99A', 'wiki'),
('25b0b16b-b55a-452d-95df-4b9d42fc16b9', 'marat_shishkin_t10', 'marat shishkin t10 Unlock Token', '8548348f-6cdb-4f80-b0f6-d007c079968d', 10, 'https://armoredwarfare.fandom.com/wiki/PL-01', 'wiki'),
('36714f3e-0b03-4242-a34c-185941c3ba90', 'zhang_feng_t10', 'zhang feng t10 Unlock Token', 'bdde29a9-ac1d-405d-8ec6-7b961c22fc4a', 10, 'https://armoredwarfare.fandom.com/wiki/Wilk_XC-8', 'wiki'),
('40a302d5-bd9b-4b08-80a7-1a3ea839a0e2', 'marat_shishkin_t9', 'marat shishkin t9 Unlock Token', '8548348f-6cdb-4f80-b0f6-d007c079968d', 9, 'https://armoredwarfare.fandom.com/wiki/M8-120_Thunderbolt_II', 'wiki'),
('43a3e61b-dbef-454a-8bb5-9b765b18933e', 'sophie_wolfli_t9', 'sophie wolfli t9 Unlock Token', 'bfc3cdeb-9bc9-46cb-ac6a-c36108f7b101', 9, 'https://armoredwarfare.fandom.com/wiki/B1_Draco', 'wiki'),
('e28191a3-4efc-4bae-b9eb-04df6cd1e16a', 'sophie_wolfli_t10', 'sophie wolfli t10 Unlock Token', 'bfc3cdeb-9bc9-46cb-ac6a-c36108f7b101', 10, 'https://armoredwarfare.fandom.com/wiki/XM1A3', 'wiki')
on conflict ("id") do nothing;
commit;
