-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."vehicle_infantry" ("capability_id", "infantry_type", "squad_count", "trooper_count", "deployment_cooldown_seconds")
values
('0e187375-860c-43ee-9c76-b08b4a86f67c', 'unspecified', NULL, NULL, NULL),
('16b25f08-95f4-43c3-a629-c5c21d386759', 'unspecified', NULL, NULL, NULL),
('171bc30d-6519-4a17-b8a5-95360c68bfb6', 'unspecified', NULL, NULL, NULL),
('1ae89c87-064b-4b6f-bdd3-eafe8aee7684', 'unspecified', NULL, NULL, NULL),
('44fc63ae-c5ee-4f96-9dd7-0213144aa345', 'unspecified', NULL, NULL, NULL),
('51298fae-a495-4ab1-a43d-e001c7f853fc', 'unspecified', NULL, NULL, NULL),
('7c3f68e7-b87e-4f05-acdc-e4b8787eadba', 'unspecified', NULL, NULL, NULL),
('852e7a0f-4d10-4223-9dc5-b8b920a4a809', 'unspecified', NULL, NULL, NULL),
('907f8c32-5058-40ba-8da0-5304087b05a0', 'unspecified', NULL, NULL, NULL),
('9d106c0b-e957-4fbb-8a9b-e32fe664bb37', 'unspecified', NULL, NULL, NULL),
('9ed0869f-9bab-498c-9e98-8aa86190acb6', 'unspecified', NULL, NULL, NULL),
('c74e379a-3e12-4773-8eb4-90308de1e66f', 'unspecified', NULL, NULL, NULL),
('c9c3f8a9-ec82-4224-9ddd-f23965aa2c40', 'unspecified', NULL, NULL, NULL),
('cb46366a-83c5-490f-8b92-d77f41a7c668', 'unspecified', NULL, NULL, NULL),
('cc5003e3-8a2e-48dd-aefa-64e61c177235', 'unspecified', NULL, NULL, NULL),
('cf51912b-ba5c-40f5-9ca2-3a8a18470d80', 'unspecified', NULL, NULL, NULL),
('e03021f3-ee01-4b8b-9a21-b71086e76d49', 'unspecified', NULL, NULL, NULL),
('e148522c-9e59-4354-86c9-57112e33311f', 'unspecified', NULL, NULL, NULL),
('e4b3f8cf-e37f-4bdb-b7a2-0f9444046215', 'unspecified', NULL, NULL, NULL),
('ee5fff3e-eb78-4cc7-9625-699cfaafe4ab', 'unspecified', NULL, NULL, NULL),
('f124da0c-59f3-4349-8ba5-e2ae3dc98bfa', 'unspecified', NULL, NULL, NULL),
('fe091109-ec62-4d20-a194-50a0e83a4216', 'unspecified', NULL, NULL, NULL)
on conflict ("capability_id", "infantry_type") do nothing;
commit;
