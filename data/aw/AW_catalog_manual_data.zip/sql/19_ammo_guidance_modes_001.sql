-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."ammo_guidance_modes" ("ammo_id", "mode_code", "lock_time_seconds", "note", "source_url", "source_type", "verification_status")
values
('07bc6e5b-d416-4c35-9e59-b59c2f8679ef', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/KNIFV_NLOS-LPS', 'wiki', 'needs_ingame_check'),
('14715f89-e215-4824-bca8-99c3421e5982', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/AFT-10', 'wiki', 'needs_ingame_check'),
('17ac2980-cbbb-4a44-9c41-e69764288b68', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/9P162M_Kornet-D1', 'wiki', 'needs_ingame_check'),
('294c11e0-597a-411d-b07b-2c61e252f173', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/9P162M_Kornet-D1', 'wiki', 'needs_ingame_check'),
('32ac7a29-ddd4-4d09-83a1-38ecba86a2d2', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/Namer_IFV', 'wiki', 'needs_ingame_check'),
('3b775fae-f72e-4090-b96d-d8d59eda7e17', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/9P162M_Kornet-D1', 'wiki', 'needs_ingame_check'),
('3e4b104d-bf65-4303-9a25-5b0260598758', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/Object_292', 'wiki', 'needs_ingame_check'),
('4442aa0e-976b-4bd9-a931-2a47e8471bf5', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/AFT-10', 'wiki', 'needs_ingame_check'),
('47f6878f-9cbc-4788-9667-72bc0ba4592e', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/K-153C_Raybolt', 'wiki', 'needs_ingame_check'),
('5324844e-9027-4b64-96e0-6aaaca0db26d', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/VCAC_Mephisto', 'wiki', 'needs_ingame_check'),
('70e29e52-158d-4e9e-9d22-8cc6b891ab9e', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/VCAC_Mephisto', 'wiki', 'needs_ingame_check'),
('76453639-c69b-49f0-a795-92b4fc421a24', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/VCAC_Mephisto', 'wiki', 'needs_ingame_check'),
('905c9928-1f55-44d9-9683-221e07c9cd11', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/Boxer_CRV', 'wiki', 'needs_ingame_check'),
('a30c9262-c3fc-42fe-aa40-c805f92a73e4', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/Sch%C3%BCtzenpanzer_Puma', 'wiki', 'needs_ingame_check'),
('a31a197a-b4ab-4ed0-835b-4672f8f0baa4', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/Boxer_RIWP', 'wiki', 'needs_ingame_check'),
('b80e9160-79c9-4f32-822a-16e6dab45e78', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/9P163-3_Kornet-EM', 'wiki', 'needs_ingame_check'),
('bdceb3ac-b0a2-49c9-a9ec-c56bca916323', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/CV90_Mk.IV', 'wiki', 'needs_ingame_check'),
('d4565ddf-d0c9-4281-bc6a-e197a9b3cb68', 'fire_and_forget', NULL, NULL, 'https://armoredwarfare.com/en/news/general/development-leclerc-t40', 'official', 'public_verified'),
('d4565ddf-d0c9-4281-bc6a-e197a9b3cb68', 'self_guided', NULL, NULL, 'https://armoredwarfare.com/en/news/general/offer-firepower', 'official', 'public_verified'),
('e1674dd9-2ad3-48dc-b585-5fdae2162293', 'self_guided', NULL, NULL, 'https://armoredwarfare.com/en/news/general/development-zbd-100', 'official', 'needs_ingame_check'),
('ef4b44dd-0e3f-460c-b2e1-4c1345ae3103', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/NM142', 'wiki', 'needs_ingame_check'),
('f3cc10d3-a5ea-4dba-8839-70da9caf12d2', 'self_guided', NULL, NULL, 'https://armoredwarfare.fandom.com/wiki/AS21_Redback', 'wiki', 'needs_ingame_check')
on conflict ("ammo_id", "mode_code") do nothing;
commit;
