-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."unlock_paths" ("id", "vehicle_id", "slug", "name", "sort_order", "note", "target_upgrade_id", "is_complete")
values
('00396806-e830-4e6c-b3eb-fda5fb747a5a', 'e857f286-f531-48de-914c-26d4594cd177', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '12c53576-12f7-4d9c-801a-be51b795e1c6', true),
('01ff8762-4f04-41e3-8996-843e02298a5c', 'ed2c1e44-9f1a-4e5c-b28d-58a681bd64de', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('02dbb8cb-0b7a-459a-872a-4f566b5a9dab', '458043b1-7aeb-43d9-be91-5f1d09824b9a', 'from_begleitpanzer_57', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('030778d0-8985-42cd-8194-52b8cba03716', 'e3f0225a-aae7-4064-89f0-8aba2b574db8', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('03311e26-b2c0-47c7-8dfd-73719d90ac97', '8577d937-23be-44b0-97b7-03a723054386', 'from_ot_65a_vydra', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('0491c95d-cfaf-4e12-aeac-c92fa94cf59f', 'dfda5759-ccb9-43bf-ac9d-73a1b4e9c41e', 'from_t_80u', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('04e350d0-425c-4683-9c52-e972f3dc9d4f', '8712c68d-7ea6-4d7e-a2dd-829dee0d2b32', 'from_chieftain_mk_2', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('052a98d4-5747-42c2-bf7a-5ee624f3cc25', '37c8b322-f893-4750-82ab-8e0806230320', 'from_magach_6b_gal_batash', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('05f49dfd-1667-4b21-a10e-9c3466e4540b', '458043b1-7aeb-43d9-be91-5f1d09824b9a', 'from_bmd_2', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('06404a5f-b69e-401a-b0b3-b23fd3b4337f', 'e59e2dc4-a957-40b1-9db8-e84adda0d8b0', 'dealer_token', '9级经销商 Token', 0, '满足此路线的所有条件；解锁后的购买费用未作为研发条件收录。', NULL, true),
('07c92718-4f46-4c57-8623-a65b96ba9387', '5d541032-be03-4696-a840-c390a0a1fd13', 'from_bmp_3', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('082573d0-88f8-4ba7-839c-9e0beff15e7c', '528193ec-32f2-48e1-8034-385ccb10b6cc', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('082845ad-a078-45a4-8224-e2de7ed3b8bc', 'bf401b26-ba15-4bc6-8f10-861ecc6b4083', 'from_erc_90_f4', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('08ea8e54-27b9-4ece-b9d9-d7dba498af7e', '642cef03-079e-4cde-8389-9b3ac213abdb', 'from_bmp_3', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('09716f51-57ee-4f31-bbae-abc3f86d84ee', 'cdcb5a19-3818-4fdf-a9db-842b12cb06e0', 'from_bmd_1', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('0b3d7d3f-543f-45f5-a4be-fb84da30d1ac', '8e561bf4-c73a-4f58-92fb-4d4efb29df21', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('0c646e67-db82-430b-81c5-01d10ded5d7f', '329f42b2-3d6e-4b52-8dfd-e2c0d28820a8', 'from_bmd_2m', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('0c6fb22a-d37e-4037-9500-229399593642', 'bd7f1f08-638c-4da4-9d15-298754eba654', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('0d0dec4b-8626-4ff6-8b4c-ac0bd5199522', '070a5cce-e20e-4a4c-83a2-bf718e4bad7d', 'from_ot_65a_vydra', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('0e0783a1-4610-4f57-b066-ca14c90fa99c', '52324ba1-ee4b-4d2d-9693-a68c1c19064b', 'from_pt_85', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('0ef52def-0be1-4fdc-b546-23c9e394f6c0', '0278bd2a-fb1d-40f0-bb25-00deafc3ef1e', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('0f1b897d-22b1-4962-b313-799c2209f8e5', '3bcafa81-13f7-440c-88dd-ceb327034df2', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('0f6a676b-1b91-4aa0-90cc-1fedbb89a764', '42324be7-c4fa-4a01-b764-c575ee0bc0db', 'from_bmd_1', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('0f747ae7-d680-4e0d-b7ad-93381650bf0b', '3be3ef1f-1061-4cfb-a068-f7bd70bacedf', 'from_type_59', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('101142e7-6337-479b-b3e8-714d5b7edccb', '071d52e5-f2b6-4977-ab1e-d23044d82ab5', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('1077e9e8-1396-458c-927b-9c3fb5b29d8b', '96d027dd-8658-475b-9c40-a4f8552b4fca', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('10d9b59d-92a3-4312-86de-722fe8a9901d', '5d4bb49c-885b-4741-a7ca-f53176644d5d', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, '19ba320c-19a2-44ec-84e9-278f3332db2f', true),
('115b454f-fa2c-459a-9b7a-91d36b71dae9', 'b33c8c08-9756-4e5d-ab2f-2dd318734bf5', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('115c4d51-7e54-46d3-ac6f-6876afcdc1ba', '743d0d5d-adff-422a-9efc-4415ba76a2ce', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('135c0318-9b67-4c61-a02f-61264c259e19', '91afa5b6-8626-4fb9-9a56-ad48c05f8cbf', 'from_t_55', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('13a2e140-b159-48fc-acf8-40e95eb175ed', '86f589c7-e3da-47a8-947d-42acd41efdc7', 'from_m1_abrams', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('13d5ae36-e78d-4f02-955b-f37caacdac38', 'e3f0225a-aae7-4064-89f0-8aba2b574db8', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '74a2d02e-b8a6-4d42-b03d-3d95d528af94', false),
('1511eba9-82f4-48e4-8d4c-33f617822c48', '5e1246a8-4063-41d9-8c27-4ddabcbca921', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('16285576-2ad4-49ba-898f-2317b84b5ed0', 'ceadbcc0-bcd1-4bde-8b71-4eac1189c164', 'from_amx_50', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('16e5a57e-49e9-4adf-87aa-238febb06336', 'de4ba998-9899-4777-8536-570cfac6740c', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('1991d439-053d-41d7-93d6-096765ca3ecc', '50216343-5541-46e1-b4f5-b4cc36d0e614', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('1a4cc406-3cbf-4ecc-b939-23debac5af1b', 'f1428c19-14a5-4e70-9296-d49073149287', 'lra_damage', '本车累计伤害解锁 LRA', 0, '官方未公布逐车门槛，required_value 保持 NULL。', '0bfd4474-c5ac-4e9d-9c89-48bf7274bb66', false),
('1a4e5296-c209-440f-9144-8c46b615f5fe', '5346d3cb-02a5-47ef-b852-0f97c500ed59', 'from_leclerc_prototype', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('1a5b18ec-8240-4c41-b3ec-57c6f5140041', '36ca60fc-6fe2-447f-8595-39dd7b1fefc4', 'lra_own_ampv', '解锁 AMPV 30 后获得 LRA', 0, NULL, 'ed87157d-3fa1-4407-a324-1452d8d7fb3c', true),
('1ca8604a-851b-4bb8-9cc7-b994e2090ecb', 'a53b6cd6-1256-4b24-9596-79bcfa38b568', 'from_bmp_1p', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('1cd14b24-6bdd-4548-8f7d-055a84de4d35', 'cf9b28f4-a79c-40eb-923f-319a9d8bb49b', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('1cd229ed-3004-40ec-a203-8c4f3262843f', '2ace8e6f-3b91-408e-a81b-73701497ed8b', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('1d4f12b1-3022-4d21-b2c2-6280258a35b2', '374ac180-0bc4-4cef-9b65-cbb14bacfd97', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('1d887eae-5249-43a0-953c-52fa7b84a4de', 'c41051ff-9498-4bc4-98e6-c0184eb84f8d', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('1e123a7a-572e-407e-b759-2d57ef223a90', '74d1ce28-1e79-4d1f-9957-82116d5ebf8f', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('1ec2519a-6c01-4065-8753-4ebcd187def5', '588f17c9-7755-47bf-bf6a-33ed3de6af92', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('21e20cb7-cead-487d-898f-1f7161307257', '9ed6086a-db40-4e62-9de0-e79075558a64', 'from_type_69', '从前置车辆研发', 0, '公开资料已列出前置关系，进度阈值、XP及额外特殊条件待游戏内确认。', NULL, false),
('220cd0e5-e43a-403c-9831-a0c38e460692', 'd49e877b-6fc3-4c82-87ac-4f653aeaef77', 'pending_confirmation', '研发条件待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false),
('27cdd91f-74e8-4d57-8d3a-d972530a93fa', 'c6fa6879-c857-4b2a-ba10-07ca21a67c1e', 'legendary_assembly', '传奇车辆组装', 0, '前置车辆和传奇蓝图两项同时满足。', NULL, false),
('27ff0a3b-2262-423e-a289-c29f8849b002', '425fee1c-e089-4c1d-ae26-15b0429a9076', 'pending_confirmation', '获取方式待核实', 0, '此条为待补全标记，不能据此判定已满足解锁条件。', NULL, false)
on conflict ("id") do nothing;
commit;
