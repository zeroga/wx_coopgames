-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."weapon_upgrade_links" ("weapon_id", "upgrade_id", "vehicle_id")
values
('0d4753dc-6a17-4406-a75b-4146c516bbf1', '929d9590-32df-4afb-b274-cde43fb6ca28', 'c2f3f80b-48d0-49d3-80c1-96f6ede5b436'),
('182bcc4e-023c-443e-963c-11ee47b9f562', 'bbcbadd5-e067-458c-b465-d81e59a5ff0a', '0085a91b-7acc-4842-a0dd-09c8c0100bf3'),
('198dd92e-5434-40f2-a06b-f060f636370b', '295c1cdd-0aef-41eb-9340-51b44090d8a4', '64b724ba-6d8c-4b2b-8de8-31baa6533e99'),
('1acc9fc8-08e9-4ece-8dc7-83c814431d27', '8fedfefd-a449-4951-bb3f-9d59f4006ad7', '1d20318a-3c06-4a09-abed-08596903b5d5'),
('2536258b-3d44-498e-8657-fd47cf3b282b', '981d64f3-8199-4da7-a327-45018f84db95', '2be295a8-7495-4a89-a4c6-efca811938d3'),
('3ed9caea-70a0-4ab1-bf9d-9531b1d7e642', '96b50f62-09e8-405b-829a-1b4d38b29060', '1158b8e1-ad74-4f0a-8c28-7a7dc68fe707'),
('3f5edbf5-0240-4f98-9d1d-63ba0d04cd1f', '89b8293d-8552-416d-ad0b-db0ee4c16a8d', '471947c2-ca67-45bd-adb3-34243b42f5f4'),
('51f8ac9c-e420-41b5-a1ec-0b2e7bfd1059', '6d596320-3cd6-4c22-8a9e-c720c6e32602', '471947c2-ca67-45bd-adb3-34243b42f5f4'),
('56b21b36-4de6-4b39-bef3-2401bf00cf5f', '239d1014-82c2-4516-a976-6569decb5fc4', '1e429df2-c669-4844-9a50-beef34a81d9e'),
('589ad46a-975c-4f5e-a53f-73753ac53226', '4ee7b9cb-8121-491c-b74c-0207a43f2617', 'bd7f1f08-638c-4da4-9d15-298754eba654'),
('59d7e5e0-1145-4890-956e-111de9d08050', 'f971e05e-4bc7-429f-83f1-d82aa7634696', '743d0d5d-adff-422a-9efc-4415ba76a2ce'),
('62d90a96-7bbc-4c3d-9f18-1c0c718fc4f8', '2f24eca6-3ee0-431d-9726-f0178057f3bd', 'a6e788c5-890b-4a63-9fde-feab9be64175'),
('71a397fd-e7e8-4e78-8018-cf438734d18c', '82927ea8-f34d-456e-8b77-14a01a0cbca4', '64b724ba-6d8c-4b2b-8de8-31baa6533e99'),
('780d97f2-6a57-46ca-93c0-e055d7eb816d', 'c7218f3c-6f5e-4f47-b691-1c80460265e6', '1f632f00-00e4-4990-bc32-2ea58f73570c'),
('7879488f-2a87-4b41-a4a0-cce64f7d580f', 'd5d0b29e-dbbe-4d78-8d94-2285fb478e0e', 'fb5f8035-4e26-46bd-8750-3a41133a638c'),
('868b9e50-4238-4eee-b496-a475fbd505a8', '295fc13f-db4d-4567-89d5-ebda03b83a15', 'dc09fc11-93f0-408c-96d7-f065aaf098c6'),
('a41f5229-ea77-4bc3-b714-013beff56079', '8abaab61-54c1-4a00-a1ca-62c94185cbf1', '13c0889b-8a30-466f-95f6-f34b242d3c60'),
('a59ede3e-820c-4a23-917b-8674699ef7ac', '29504cc5-7006-474c-b3ec-c2d80d058d15', 'a6e788c5-890b-4a63-9fde-feab9be64175'),
('a9898c12-7f6a-4824-a948-250c57ce1058', '0afcf9b5-6e50-48ea-a68c-36f7e598e950', '2be295a8-7495-4a89-a4c6-efca811938d3'),
('b466dbe3-e7b1-4cf3-a201-806d651f7d82', '9d2d8a33-4847-4c04-975b-17bd6d5e42a7', '62b35f0e-9f21-4f6d-8d5c-80669d931d1a'),
('b530b4bb-2bbb-4ec2-ac54-ed5f83d384d0', '9c79f0ac-46b4-4828-a0d4-5c5225b7fd30', '743d0d5d-adff-422a-9efc-4415ba76a2ce'),
('c22423c7-8a99-4d17-a684-34a5083d4803', '86c1e3d6-c8d9-4508-acd1-c1dafbf8b058', '62b35f0e-9f21-4f6d-8d5c-80669d931d1a'),
('cc9b6e4a-5a6a-42d3-b6cd-b3fed5941f14', '321e709e-28ba-40a3-b79a-8ff58c579d4a', '2a1c4f58-a2f4-44e7-a2ce-11d0e558e1f5'),
('d17edadb-5049-41cc-bedf-faca6c44e722', '3221f6d7-336e-4a14-b00e-2b44cb757cfc', '64b724ba-6d8c-4b2b-8de8-31baa6533e99'),
('d3167c13-1efa-4e58-be91-4760e1d6883c', 'a6653e8f-ce26-45cb-95e9-6142b6fe4230', 'f8f72ef5-71ae-497f-a1f8-87a5f8f9f45d'),
('d4a959ff-fc7d-4d1b-a5c2-596eafa3b064', 'f3f67012-9286-490e-94f9-2d3783847b84', '50216343-5541-46e1-b4f5-b4cc36d0e614'),
('d6100372-46d5-4565-a564-edbc5a7d3791', '80c8826f-be10-4103-b94f-b965c2dbda7d', '713cc161-f358-475f-a1aa-e75c87edd776'),
('dc119c92-9c46-4683-b95a-d44e789574ef', '388caff2-6f52-45ba-8313-24bcf314f3a5', 'd52cab15-129b-4636-8134-af9496055dcb'),
('dd39a966-7d85-4d84-b817-0ac97e2f83c7', 'f25f4e73-6ede-4424-a6a8-8a274453013b', '1d20318a-3c06-4a09-abed-08596903b5d5'),
('e7307b2a-fd47-4fb0-80bd-e0e98e2b444c', 'f88978aa-67e1-498a-b637-e79812d4e792', 'b568304d-5197-4cad-8899-cfef305de516'),
('fbed0d01-ec9a-4191-999b-c391dd12788e', 'ca93cd97-d845-402c-a4d1-d06d560ed36c', '64b724ba-6d8c-4b2b-8de8-31baa6533e99')
on conflict ("weapon_id", "upgrade_id") do nothing;
commit;
