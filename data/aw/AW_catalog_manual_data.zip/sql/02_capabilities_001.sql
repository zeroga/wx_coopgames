-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."capabilities" ("code", "name_zh", "category", "description", "parent_code")
values
('active_camo', '主动隐蔽', 'ability', NULL, NULL),
('active_skill', '主动技能', 'ability', NULL, NULL),
('aps', '主动防护系统', 'defense', NULL, NULL),
('atgm', '反坦克导弹', 'weapon', NULL, NULL),
('autocannon', '机炮', 'weapon', NULL, NULL),
('drone', '无人机', 'recon', NULL, NULL),
('era', '爆炸反应装甲', 'armor', NULL, NULL),
('infantry_squad', '可部署步兵班', 'infantry', NULL, NULL),
('laser_warning', '激光告警', 'defense', NULL, NULL),
('magazine', '弹匣装填', 'loading', NULL, NULL),
('missile_warning', '导弹预警', 'defense', NULL, NULL),
('nera', '非爆炸反应装甲', 'armor', NULL, NULL),
('recon', '侦察能力', 'recon', NULL, NULL),
('smoke', '烟幕', 'defense', NULL, NULL),
('special_loading', '特殊装填机制', 'loading', NULL, NULL),
('special_mobility', '特殊机动能力', 'mobility', NULL, NULL),
('special_optics', '特殊观瞄', 'recon', NULL, NULL),
('synergy', '协同增益', 'passive_ability', NULL, NULL),
('troop_compartment', '步兵舱', 'structure', NULL, NULL),
('unmanned_turret', '无人炮塔', 'structure', NULL, NULL),
('hard_kill_aps', '硬杀 APS', 'defense', NULL, 'aps'),
('soft_kill_aps', '软杀 APS', 'defense', NULL, 'aps')
on conflict ("code") do nothing;
commit;
