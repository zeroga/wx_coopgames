-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."vehicle_progression_edges" ("id", "from_vehicle_id", "to_vehicle_id", "edge_type", "display_order", "source_url", "note", "verification_status")
values
('e785495f-b438-4308-9d03-e8a49cafda2e', '329f42b2-3d6e-4b52-8dfd-e2c0d28820a8', '749f48fc-e226-4e0a-901a-16d428658482', 'token', 0, 'https://armoredwarfare.fandom.com/wiki/M8-120_Thunderbolt_II', '显示该车产出的经销商 Token 可解锁目标车；不是普通直系前置。', 'public_verified'),
('e8821dbb-d12a-4ccd-9260-479776b1bb6e', '21f96b13-6122-4c99-9357-9ed8aab9e075', '6138e381-07bb-4802-913d-e139628d318a', 'normal', 0, 'https://armoredwarfare.fandom.com/wiki/T-62', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('e95ba22d-bc3f-49c8-b28d-7a28b178b2b0', '903201b5-8dff-4ed6-8fbd-ce3e114dcfd5', 'bee45b8a-f17f-4c36-b730-a552fffd5402', 'branch', 0, 'https://armoredwarfare.fandom.com/wiki/LAV-300', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('e9f011d6-a458-4208-b3ca-f76600026df1', 'e37a96bf-a9e0-4acf-bba8-24d6a7817f70', '2b2be610-bfd4-4c2a-9329-79fb8789db9e', 'normal', 0, 'https://armoredwarfare.fandom.com/wiki/T-80', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('ea998bac-5ec1-4893-be13-cd6cba45ad32', 'ed2c1e44-9f1a-4e5c-b28d-58a681bd64de', 'e3f0225a-aae7-4064-89f0-8aba2b574db8', 'token', 0, 'https://armoredwarfare.fandom.com/wiki/CRAB', '显示该车产出的经销商 Token 可解锁目标车；不是普通直系前置。', 'public_verified'),
('eb95e44e-92e8-4a22-ba0f-7ac7ad83b497', 'a6b18b44-cfcf-4bfb-a9f2-abfc2020ab90', 'dc09fc11-93f0-408c-96d7-f065aaf098c6', 'normal', 0, 'https://armoredwarfare.fandom.com/wiki/Tank_Test_Bed', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('ebd23048-786c-4c51-a22a-9e3ea83402bc', 'eafab0a3-55dd-4936-a131-a8577e2c2330', 'b568304d-5197-4cad-8899-cfef305de516', 'normal', 0, 'https://armoredwarfare.fandom.com/wiki/Leopard_2AV', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('ec4ecd4d-eabc-44f4-acf3-33aeb0abf907', '8704cf4e-e64f-4d84-8aba-574a7a4acaf3', 'a53b6cd6-1256-4b24-9596-79bcfa38b568', 'normal', 0, 'https://armoredwarfare.fandom.com/wiki/BVP-M2_SKCZ_%C5%A0akal', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('ec750073-159b-462c-8b34-20d0ed4b8054', '749f48fc-e226-4e0a-901a-16d428658482', 'aee06add-8fe1-43a0-ab46-23e76a1eecf6', 'token', 0, 'https://armoredwarfare.fandom.com/wiki/PL-01', '显示该车产出的经销商 Token 可解锁目标车；不是普通直系前置。', 'public_verified'),
('ed0dfa9f-1777-43cf-b8be-cecc9e5ad242', '156e6337-8667-48ee-bc28-73df5821aaad', '90d54748-0c0c-4bc8-9cc2-cbe82f530505', 'branch', 0, 'https://armoredwarfare.fandom.com/wiki/Wiesel_1_HOT', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('ee535681-bcbe-46e5-8939-db99ad6f2d35', 'd77be0fd-25d6-4877-9fef-06fb10cb9953', '329f42b2-3d6e-4b52-8dfd-e2c0d28820a8', 'branch', 0, 'https://armoredwarfare.fandom.com/wiki/T-90', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('efc2dc6e-3d43-4ed5-94b8-e5f333f5b7e9', '320ca031-6fae-40de-902f-a291e7561fea', '7909041f-33b6-4ed7-a069-3d21293444a4', 'token', 0, 'https://armoredwarfare.fandom.com/wiki/Panzerhaubitze_2000', '显示该车产出的经销商 Token 可解锁目标车；不是普通直系前置。', 'public_verified'),
('f05bed3e-13f0-4546-a159-a5481b719739', '6138e381-07bb-4802-913d-e139628d318a', '30ec53a9-7666-4cc8-a80c-bbaa84cf2eb8', 'branch', 0, 'https://armoredwarfare.fandom.com/wiki/T-72B', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('f2452459-e2e7-406b-8414-9b21c3e0145b', '963743d9-6404-4cd7-9ea0-7ef2e215d29b', '37c8b322-f893-4750-82ab-8e0806230320', 'branch', 0, 'https://armoredwarfare.fandom.com/wiki/Magach_7C', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('f32582ad-9786-4f5d-8966-3e7b1e1b7699', 'ec8194ac-14c6-4bf2-8b9c-c78804642bf2', 'bf401b26-ba15-4bc6-8f10-861ecc6b4083', 'normal', 0, 'https://armoredwarfare.fandom.com/wiki/LAV-600', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('f363a807-233a-4f73-9835-2c8cb8b6e322', '798c4f70-6e3e-420f-939c-45288041ba0e', 'dcb35303-8e69-4119-9984-34373b1c937f', 'token', 0, 'https://armoredwarfare.fandom.com/wiki/Challenger_2', '显示该车产出的经销商 Token 可解锁目标车；不是普通直系前置。', 'public_verified'),
('f37e2a61-3e5d-441c-b327-266902a4a5a2', 'd779c971-474f-46bb-b7c5-e057d95bd8ee', 'c1469c1a-c6f9-402d-9883-ce729ff32589', 'branch', 0, 'https://armoredwarfare.fandom.com/wiki/Type_79', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('f5d2f22e-c638-436e-a37a-052161d6a5cd', 'a71748b3-121e-49f7-8cb0-2f1e0f2e87a3', '0f51ebf2-266e-412f-ae07-2d2a25412d07', 'normal', 0, 'https://armoredwarfare.fandom.com/wiki/Wiesel_1_TOW', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('fbf93840-d796-4068-bea4-da5ccd143f2c', '156e6337-8667-48ee-bc28-73df5821aaad', '13c0889b-8a30-466f-95f6-f34b242d3c60', 'branch', 0, 'https://armoredwarfare.fandom.com/wiki/FV510_Warrior_MILAN', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check'),
('fd24ea57-690a-4a4a-a52e-abf3527db769', '8e1bf45a-1785-4723-a8c1-50701a414f8f', '5c8b4a7e-d01d-4d6e-9808-a57a11f8048c', 'normal', 0, 'https://armoredwarfare.fandom.com/wiki/BMP-2', '资料明确列出的前后显示关系，完整解锁条件待核实。', 'needs_ingame_check')
on conflict ("id") do nothing;
commit;
