-- MANUAL DATA IMPORT ONLY. No DDL and no automatic execution.
-- Existing primary keys are kept; different natural-key/ID collisions fail.
begin;
set local lock_timeout='3s';
set local statement_timeout='20s';
set local idle_in_transaction_session_timeout='30s';
set local standard_conforming_strings=on;
insert into public."ammo_trait_links" ("ammo_id", "trait_code", "source_url", "source_type", "verification_status")
values
('037d2928-768c-4dee-be59-8a7e5057be56', 'tandem', 'https://armoredwarfare.fandom.com/wiki/PL-01', 'wiki', 'needs_ingame_check'),
('05e37577-e095-444b-9c92-d431d18e921f', 'pele', 'https://armoredwarfare.fandom.com/wiki/Boxer_CRV', 'wiki', 'needs_ingame_check'),
('0d077b99-8e33-41e8-a322-5cb8747c4c23', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Sabra_Mk.2', 'wiki', 'needs_ingame_check'),
('0e5e14f4-6d49-4f33-be1c-cb8e0a72aa95', 'pele', 'https://armoredwarfare.fandom.com/wiki/Wilk_XC-8', 'wiki', 'needs_ingame_check'),
('0ffe1148-cfa8-4603-a22b-62e878ef3cc5', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/M60A3_SLEP', 'wiki', 'needs_ingame_check'),
('10a319a9-0bf0-403d-ab4d-92cdd19923c4', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/MPF_Light_Tank', 'wiki', 'needs_ingame_check'),
('11f4d553-2cdf-4078-834e-eb74556d40db', 'tandem', 'https://armoredwarfare.fandom.com/wiki/Type_99A2', 'wiki', 'needs_ingame_check'),
('129791cf-8d9f-4eb1-88ac-b9a8c77a7c3b', 'pele', 'https://armoredwarfare.fandom.com/wiki/KTO_Rosomak_M1M', 'wiki', 'needs_ingame_check'),
('196a47f4-fa2a-46e7-ab9b-199916b7a86d', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/M60-2000', 'wiki', 'needs_ingame_check'),
('20a0074e-dd7b-44a4-8308-b07d43896a2b', 'thermobaric', 'https://armoredwarfare.fandom.com/wiki/T-15_Armata', 'wiki', 'needs_ingame_check'),
('24455ca8-31e2-4128-951a-df7b88d318f4', 'programmable', 'https://armoredwarfare.fandom.com/wiki/T-80BVM', 'wiki', 'needs_ingame_check'),
('2764bf5c-a491-4583-a987-4307eaf9b7e0', 'kinetic_missile', 'https://armoredwarfare.fandom.com/wiki/M8_MGM-166', 'wiki', 'needs_ingame_check'),
('2ef4ce1a-b9ef-49d1-9b16-48e445567da0', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Merkava_Mk.4M_Barak', 'wiki', 'needs_ingame_check'),
('34f57cf5-aa0e-4de0-9235-06936229aaf5', 'tandem', 'https://armoredwarfare.fandom.com/wiki/Type_99A', 'wiki', 'needs_ingame_check'),
('472f9720-b7ba-43a0-b414-335ef4f8de8e', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/M8-120_Hades', 'wiki', 'needs_ingame_check'),
('47f6878f-9cbc-4788-9667-72bc0ba4592e', 'top_attack', 'https://armoredwarfare.fandom.com/wiki/K-153C_Raybolt', 'wiki', 'needs_ingame_check'),
('4fafbe99-6aff-49c4-983a-40b9631f9a31', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/CATTB', 'wiki', 'needs_ingame_check'),
('52dd3242-2b8c-45ae-a9e0-0bfa96d185a7', 'pele', 'https://armoredwarfare.fandom.com/wiki/Flakpanzer_Gepard', 'wiki', 'needs_ingame_check'),
('533f1789-a3d9-424e-92aa-d274f6ecf146', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Merkava_Mk.3_Barak_Zoher', 'wiki', 'needs_ingame_check'),
('5c1d87af-d207-417f-8716-5d01fa8f4962', 'top_attack', 'https://armoredwarfare.fandom.com/wiki/Boxer_RIWP', 'wiki', 'needs_ingame_check'),
('5d67692b-2918-4f09-bb68-8f1f70e98c10', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/K21_XC-8', 'wiki', 'needs_ingame_check'),
('5d99b073-6dee-4485-b774-da9d05408f40', 'pele', 'https://armoredwarfare.fandom.com/wiki/Sch%C3%BCtzenpanzer_Puma', 'wiki', 'needs_ingame_check'),
('604ff00b-4bb2-4e62-bc48-79f0dea0c89a', 'pele', 'https://armoredwarfare.fandom.com/wiki/Borsuk', 'wiki', 'needs_ingame_check'),
('6101062d-2359-4427-9392-aa0e6afc3244', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/M1A2C_Abrams', 'wiki', 'needs_ingame_check'),
('6a0fedad-f64b-47a3-bdf1-4b513946bda5', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/WZ-1224', 'wiki', 'needs_ingame_check'),
('7421f5da-5537-4f40-909f-99de02105fe8', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Tank_Test_Bed', 'wiki', 'needs_ingame_check'),
('77c5a6a7-160d-4571-a0e5-d89e012add17', 'pele', 'https://armoredwarfare.fandom.com/wiki/XM247_Sergeant_York', 'wiki', 'needs_ingame_check'),
('83bcc09e-4f9a-4adf-ace3-1f5345fa9b25', 'tandem', 'https://armoredwarfare.fandom.com/wiki/Type_99A', 'wiki', 'needs_ingame_check'),
('8b4a0310-fabd-4e17-9a99-276bacc40b13', 'programmable', 'https://armoredwarfare.fandom.com/wiki/Leclerc', 'wiki', 'needs_ingame_check'),
('8fba5426-fb42-40d1-8203-4439c62f9e21', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/M1A2C_Abrams_Hades', 'wiki', 'needs_ingame_check'),
('959f14c6-5bbb-4fcf-985e-00091d1da83b', 'pele', 'https://armoredwarfare.fandom.com/wiki/ZSU-23-4_Shilka', 'wiki', 'needs_ingame_check'),
('9df07cb6-1939-4e04-ba08-f4a88e6c1fcc', 'pele', 'https://armoredwarfare.fandom.com/wiki/Marder_2', 'wiki', 'needs_ingame_check'),
('a0e2b49c-5cd1-45cf-a0f4-bb7a95109abf', 'programmable', 'https://armoredwarfare.fandom.com/wiki/T-90M_Proryv', 'wiki', 'needs_ingame_check'),
('a27da73c-5869-4a85-b0cb-e77a8edf0463', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/K1A1', 'wiki', 'needs_ingame_check'),
('a30c65cb-bfae-48be-a8df-5bb5a6fe2fba', 'programmable', 'https://armoredwarfare.fandom.com/wiki/M1A2C_Abrams_Hades', 'wiki', 'needs_ingame_check'),
('a31a197a-b4ab-4ed0-835b-4672f8f0baa4', 'top_attack', 'https://armoredwarfare.fandom.com/wiki/Boxer_RIWP', 'wiki', 'needs_ingame_check'),
('a81361b9-08e3-405b-bf05-f7cd0de6221b', 'pele', 'https://armoredwarfare.fandom.com/wiki/Arjun_Mk.IA', 'wiki', 'needs_ingame_check'),
('a990ec92-2493-40f9-8724-7f5103a2f228', 'programmable', 'https://armoredwarfare.fandom.com/wiki/T-14_Armata', 'wiki', 'needs_ingame_check'),
('aa08c0f7-f666-42dc-9697-9ebe176f351a', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Wilk_XC-8', 'wiki', 'needs_ingame_check'),
('adf0ed5b-4f94-4048-9a5a-f1117cfd8661', 'pele', 'https://armoredwarfare.fandom.com/wiki/Namer_IFV', 'wiki', 'needs_ingame_check'),
('b0040654-e8df-438b-ae64-ea64087a64d3', 'pele', 'https://armoredwarfare.fandom.com/wiki/Ajax', 'wiki', 'needs_ingame_check'),
('b3ee1aaf-a540-4b37-8ff1-6c33e5988e63', 'tandem', 'https://armoredwarfare.fandom.com/wiki/Merkava_Mk.4', 'wiki', 'needs_ingame_check'),
('b76facaf-0277-4bce-90bf-d77ce2aabd60', 'programmable', 'https://armoredwarfare.fandom.com/wiki/M1A2C_Abrams', 'wiki', 'needs_ingame_check'),
('b80e9160-79c9-4f32-822a-16e6dab45e78', 'tandem', 'https://armoredwarfare.fandom.com/wiki/9P163-3_Kornet-EM', 'wiki', 'needs_ingame_check'),
('beea3430-4646-42df-8daf-94bde8b75524', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Type_90', 'wiki', 'needs_ingame_check'),
('c74be59f-423f-4071-86dc-5a1fd330d6e6', 'programmable', 'https://armoredwarfare.fandom.com/wiki/Stridsvagn_122', 'wiki', 'needs_ingame_check'),
('c9f2381d-6bb2-4e7f-8356-b5bd3e1566dc', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Challenger_1_Falcon', 'wiki', 'needs_ingame_check'),
('d03aa159-abd1-4d4e-bf68-3a38df91868c', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/Merkava_Mk.4', 'wiki', 'needs_ingame_check'),
('d4565ddf-d0c9-4281-bc6a-e197a9b3cb68', 'top_attack', 'https://armoredwarfare.com/en/news/general/offer-firepower', 'official', 'public_verified'),
('d65140f5-8e51-4996-a6ec-863902ffbb7f', 'multipurpose', 'https://armoredwarfare.fandom.com/wiki/CV90120_Ghost', 'wiki', 'needs_ingame_check')
on conflict ("ammo_id", "trait_code") do nothing;
commit;
