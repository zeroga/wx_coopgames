set local lock_timeout='3s';set local statement_timeout='20s';
insert into public.vehicles(slug,name,tier,vehicle_class,nation,acquisition_type,is_premium,is_currently_researchable,release_status,acquisition_note,source_url,source_type,verification_status,last_checked_at,source_note)
values
('zbd_100','ZBD-100',10,'AFV','China','event',true,false,'announced','Into the West：Level 15，免费 Path of the Pilgrim 可达。','https://armoredwarfare.com/en/news/general/west-battle-path-prize-highlights','official','public_verified',now(),'官方已公布身份与奖励；上线状态和最终数值未游戏内核验，性能留 NULL。'),
('type_100_csv','Type 100 CSV',10,'TD','China','event',true,false,'announced','Into the West：Level 30，需要完整 Battle Path 权限。','https://armoredwarfare.com/en/news/general/west-battle-path-prize-highlights','official','public_verified',now(),'官方已公布身份与奖励；上线状态和最终数值未游戏内核验，性能留 NULL。'),
('ztz_100','ZTZ-100',10,'MBT','China','event',true,false,'announced','Into the West：Level 50，需要完整 Battle Path 权限。','https://armoredwarfare.com/en/news/general/west-battle-path-prize-highlights','official','public_verified',now(),'官方已公布身份与奖励；上线状态和最终数值未游戏内核验，性能留 NULL。')
on conflict(slug) do nothing;
insert into public.capabilities(code,name_zh,category) values('synergy','协同增益','passive_ability') on conflict do nothing;
insert into public.vehicle_capabilities(vehicle_id,capability_code,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select v.id,'synergy','default','三个活动车型接近时互相提供增益；三车齐聚可形成反制制导导弹保护区。','https://armoredwarfare.com/en/news/general/west-battle-path-prize-highlights','official','public_verified',now()
from public.vehicles v where v.slug in ('zbd_100','type_100_csv','ztz_100') on conflict(vehicle_id,capability_code,variant_key) do nothing;
insert into public.unlock_paths(vehicle_id,slug,name,is_complete)
select id,'into_the_west_level','Into the West 活动奖励',true from public.vehicles where slug in ('zbd_100','type_100_csv','ztz_100') on conflict do nothing;
insert into public.unlock_requirements(unlock_path_id,slug,requirement_type,event_code,operator,required_value,unit,description,verification_status,source_url,source_type,last_checked_at)
select p.id,'level','event_level','into_the_west_2026','>=',case v.slug when 'zbd_100' then 15 when 'type_100_csv' then 30 else 50 end,'level','达到指定 Battle Path 等级。','public_verified',v.source_url,'official',now()
from public.unlock_paths p join public.vehicles v on v.id=p.vehicle_id where p.slug='into_the_west_level' on conflict do nothing;
insert into public.unlock_requirements(unlock_path_id,slug,requirement_type,event_code,operator,description,verification_status,source_url,source_type,last_checked_at)
select p.id,'access','event_access','into_the_west_2026','exists','需要 Path of the Warrior 完整 Battle Path 权限。','public_verified','https://armoredwarfare.com/en/news/general/west-battle-path-info-and-preorder','official',now()
from public.unlock_paths p join public.vehicles v on v.id=p.vehicle_id where p.slug='into_the_west_level' and v.slug in ('type_100_csv','ztz_100') on conflict do nothing;
insert into public.vehicle_weapons(vehicle_id,slug,name,weapon_type,caliber_mm,configuration_key,source_url,source_type,verification_status,last_checked_at,note)
select v.id,s.weapon_slug,s.name,s.weapon_type,s.caliber,'announced',s.url,'official','needs_ingame_check',now(),'官方游戏开发介绍所列武器；尚未以最终上线版本核对。'
from(values
 ('zbd_100','zpt_02','30mm ZPT-02 Autocannon','autocannon',30,'https://armoredwarfare.com/en/news/general/development-zbd-100'),
 ('zbd_100','hj_13','HJ-13 ATGM Launcher','atgm',null,'https://armoredwarfare.com/en/news/general/development-zbd-100'),
 ('zbd_100','pf11e','PF11E Rocket Launcher','rocket',null,'https://armoredwarfare.com/en/news/general/development-zbd-100'),
 ('type_100_csv','autocannon_40','40mm Autocannon','autocannon',40,'https://armoredwarfare.com/en/news/general/development-type-100-csv'),
 ('ztz_100','cannon_105','105mm Cannon','cannon',105,'https://armoredwarfare.com/en/news/general/development-ztz-100'),
 ('ztz_100','machinegun_12_7','12.7mm Machine Gun','machine_gun',12.7,'https://armoredwarfare.com/en/news/general/development-ztz-100')
) s(vehicle_slug,weapon_slug,name,weapon_type,caliber,url) join public.vehicles v on v.slug=s.vehicle_slug on conflict(vehicle_id,slug) do nothing;
insert into public.vehicle_ammo(weapon_id,slug,name,ammo_type,is_missile,is_guided,source_url,source_type,verification_status,last_checked_at,note)
select w.id,s.ammo_slug,s.name,s.ammo_type,true,s.is_guided,'https://armoredwarfare.com/en/news/general/development-zbd-100','official','needs_ingame_check',now(),'官方公布机制；伤害/穿深/弹速未知，保持 NULL。'
from(values('hj_13','hj_13','HJ-13 ATGM','atgm',true),('pf11e','pf11e','PF11E Thermobaric Rocket','other',false)) s(weapon_slug,ammo_slug,name,ammo_type,is_guided)
join public.vehicle_weapons w on w.slug=s.weapon_slug join public.vehicles v on v.id=w.vehicle_id where v.slug='zbd_100' on conflict do nothing;
insert into public.ammo_guidance_modes(ammo_id,mode_code,source_url,source_type,verification_status)
select a.id,'self_guided',a.source_url,'official','needs_ingame_check' from public.vehicle_ammo a join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicles v on v.id=w.vehicle_id
where v.slug='zbd_100' and a.slug='hj_13' on conflict do nothing;
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,case a.slug when 'hj_13' then 'tandem' else 'thermobaric' end,a.source_url,'official','needs_ingame_check'
from public.vehicle_ammo a join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicles v on v.id=w.vehicle_id where v.slug='zbd_100' on conflict do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,note)
values('20261001_announced_into_the_west','completed',now(),now(),'3 officially announced Tier 10 rewards; release not asserted; performance NULL; event conditions and Synergy structured.') on conflict do nothing;

