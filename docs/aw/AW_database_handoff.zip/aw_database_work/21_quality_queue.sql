set local lock_timeout='3s';set local statement_timeout='20s';
update public.vehicle_token_rewards set source_type='wiki' where source_type is null;
update public.unlock_requirements set scope=scope-'token_tier' where requirement_type='dealer_token';
update public.unlock_paths p set is_complete=true where p.target_upgrade_id is null and p.slug='dealer_token'
 and exists(select 1 from public.unlock_requirements r where r.unlock_path_id=p.id)
 and not exists(select 1 from public.unlock_requirements r where r.unlock_path_id=p.id and
 (r.verification_status not in ('public_verified','ingame_verified') or r.requirement_type<>'dealer_token' or r.token_id is null or r.required_value is null));
insert into private.aw_data_issues(issue_key,entity_type,entity_id,severity,description)
select 'missing_ammo_'||v.slug,'vehicle',v.id,'warning','没有可可靠关联的弹药资料；后续按 source_url 或游戏内核实补齐。'
from public.vehicles v where v.release_status<>'announced' and not exists(select 1 from public.vehicle_weapons w join public.vehicle_ammo a on a.weapon_id=w.id where w.vehicle_id=v.id) on conflict do nothing;
insert into private.aw_data_issues(issue_key,entity_type,entity_id,severity,description)
select 'pending_unlock_'||v.slug,'vehicle',v.id,'warning','科技树获取方式仍含待核实占位条件；不能视为完整解锁关系。'
from public.vehicles v where exists(select 1 from public.unlock_paths p where p.vehicle_id=v.id and p.slug='pending_confirmation') on conflict do nothing;
insert into private.aw_data_issues(issue_key,entity_type,entity_id,severity,description)
select 'missing_weapon_'||v.slug,'vehicle',v.id,'warning','未取得可核实的武器记录；不从真实车辆资料猜游戏武器。'
from public.vehicles v where not exists(select 1 from public.vehicle_weapons w where w.vehicle_id=v.id) on conflict do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,note)
values('20261001_quality_queue','completed',now(),now(),'Remaining missing ammo/weapon and placeholder unlock facts persisted as resumable QA queue; no guessed data.')
on conflict do nothing;
