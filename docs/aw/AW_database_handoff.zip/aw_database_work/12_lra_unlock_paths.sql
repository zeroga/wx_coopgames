set local lock_timeout='3s';set local statement_timeout='20s';
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select id,'lra_unlock','Loitering Recon Ammunition','ammo','upgrade','两条替代路线：本车达成伤害门槛（数值未知），或解锁 AMPV 30。','https://armoredwarfare.com/en/news/general/developer-diary-loitering-recon-ammunition','official','public_verified',now()
from public.vehicles where slug in ('bmd_2','vbl','wiesel_1_tow','bmd_4','fv721_fox','sabre','bmd_2m','vbl_ingwe','wiesel_1_hot','vbr','2t_stalker','crab','sphinx','ebrc_jaguar','k_153c_raybolt','rst_v_shadow','k_4386d_typhoon_vdv') on conflict(vehicle_id,slug) do nothing;
insert into public.vehicle_capabilities(vehicle_id,capability_code,variant_key,availability,upgrade_id,effect_description,source_url,source_type,verification_status,last_checked_at)
select vehicle_id,'recon','lra','upgrade',id,'LRA 第一人称侦察；解锁条件见模块解锁路径。',source_url,'official','public_verified',now()
from public.vehicle_upgrades where slug='lra_unlock' on conflict(vehicle_id,capability_code,variant_key) do nothing;
insert into public.unlock_paths(vehicle_id,slug,name,target_upgrade_id,is_complete)
select vehicle_id,'lra_own_ampv','解锁 AMPV 30 后获得 LRA',id,true from public.vehicle_upgrades where slug='lra_unlock' on conflict(vehicle_id,slug) do nothing;
insert into public.unlock_paths(vehicle_id,slug,name,target_upgrade_id,is_complete,note)
select vehicle_id,'lra_damage','本车累计伤害解锁 LRA',id,false,'官方未公布逐车门槛，required_value 保持 NULL。'
from public.vehicle_upgrades where slug='lra_unlock' on conflict(vehicle_id,slug) do nothing;
insert into public.unlock_requirements(unlock_path_id,slug,requirement_type,source_vehicle_id,operator,description,verification_status,source_url,source_type,last_checked_at)
select p.id,'own_ampv','own_vehicle',v.id,'exists','解锁 AMPV 30 可解锁该车 LRA。','public_verified','https://armoredwarfare.com/en/news/general/developer-diary-loitering-recon-ammunition','official',now()
from public.unlock_paths p cross join public.vehicles v where p.slug='lra_own_ampv' and v.slug='ampv_30' on conflict(unlock_path_id,slug) do nothing;
insert into public.unlock_requirements(unlock_path_id,slug,requirement_type,source_vehicle_id,operator,unit,description,verification_status,source_url,source_type,last_checked_at)
select p.id,'damage','damage',p.vehicle_id,'>=','damage','本车累计伤害达到门槛；具体数值待游戏内核实。','needs_ingame_check','https://armoredwarfare.com/en/news/general/developer-diary-loitering-recon-ammunition','official',now()
from public.unlock_paths p where p.slug='lra_damage' on conflict(unlock_path_id,slug) do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,row_counts,note)
values('20261001_lra_cross_vehicle_unlocks','completed',now(),now(),jsonb_build_object('upgrades',17,'paths',34),'Official OR paths: own AMPV 30 OR per-vehicle damage. Unpublished damage thresholds remain NULL.') on conflict do nothing;

