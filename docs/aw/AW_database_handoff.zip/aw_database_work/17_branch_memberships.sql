set local lock_timeout='3s';set local statement_timeout='20s';
insert into public.tech_tree_branches(slug,name,dealer_id,source_url,verification_status)
select 'russian_fire_support','Russian Fire Support',id,'https://armoredwarfare.com/en/news/general/branch-month-russian-fire-support','needs_ingame_check'
from public.dealers where slug='marat_shishkin' on conflict(slug) do nothing;
insert into public.vehicle_branch_memberships(vehicle_id,branch_id,display_order)
select v.id,b.id,x.ord from(values('bmd_1',1),('bmd_1p',2),('bmd_2',3),('bmd_4',4),('bmd_2m',5),('ramka_99',6),('bmpt_72_terminator_2',7),('t15_armata',8)) x(slug,ord)
join public.vehicles v on v.slug=x.slug cross join public.tech_tree_branches b where b.slug='russian_fire_support' on conflict do nothing;
insert into private.aw_data_issues(issue_key,entity_type,severity,description)
values('branch_russian_fire_support_current','branch','warning','Russian Fire Support 成员依据官方历史分支介绍；当前版本分支成员和替代节点待游戏内核实。') on conflict do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,note)
values('20261001_branch_membership','completed',now(),now(),'Official named Russian Fire Support branch, historical source explicitly flagged for current-version check.') on conflict do nothing;

