set local lock_timeout='3s';set local statement_timeout='20s';
insert into private.aw_data_issues(issue_key,entity_type,entity_id,severity,description,original_data,resolved_at)
select 'merged_weapon_'||w.slug,'weapon',w.id,'error','武器名称把主炮和 ATGM 合并；参数与弹药关联无法可靠区分，已隔离，替代记录只保留明确名称。',to_jsonb(w),now()
from public.vehicle_weapons w where name like '% ... %' on conflict do nothing;
insert into private.aw_data_issues(issue_key,entity_type,entity_id,severity,description,original_data,resolved_at)
select 'merged_weapon_ammo_'||a.slug,'ammo',a.id,'error','弹药所属武器来自合并名称；已隔离，不把不可靠关联留在筛选数据中。',to_jsonb(a),now()
from public.vehicle_ammo a join public.vehicle_weapons w on w.id=a.weapon_id where w.name like '% ... %' on conflict do nothing;
insert into public.vehicle_weapons(vehicle_id,slug,name,weapon_type,caliber_mm,configuration_key,source_url,source_type,verification_status,note,last_checked_at)
select v.id,x.slug,x.name,x.type,x.caliber,'source_summary',v.source_url,'wiki','needs_ingame_check','名称来自旧资料明确的两段武器名；混合参数已隔离，数值留 NULL 待核实。',now()
from(values
 ('bwp_2000','hv60_70_cannon','60mm HV60/70 Rifled Cannon','cannon',60),
 ('bwp_2000','ingwe_launcher','Ingwe ATGM Launcher','atgm',null),
 ('rdf_lt_ares','xm274_12_cannon','75mm XM274 Ares Smoothbore Cannon (12 rounds)','cannon',75),
 ('rdf_lt_ares','atgm_launcher','ATGM Launcher','atgm',null)
) x(vehicle_slug,slug,name,type,caliber) join public.vehicles v on v.slug=x.vehicle_slug on conflict(vehicle_id,slug) do nothing;
delete from public.vehicle_weapons where name like '% ... %';
insert into private.aw_data_issues(issue_key,entity_type,entity_id,severity,description,original_data,resolved_at)
select 'ampv_launcher_split','weapon',w.id,'error','AMPV 30 的 Brimstone + Javelin/LRA 共用发射器被文本分隔符拆成两条；无参数的片段已合并移除。',to_jsonb(w),now()
from public.vehicle_weapons w join public.vehicles v on v.id=w.vehicle_id where v.slug='ampv_30' and w.slug='brimstone__weapon1' on conflict do nothing;
update public.vehicle_weapons w set name='Brimstone + Javelin/LRA ATGM Launcher',source_note='Wiki 明列合并发射器，原名称分隔解析已修正。',last_checked_at=now()
from public.vehicles v where v.id=w.vehicle_id and v.slug='ampv_30' and w.slug='javelin_lra_atgm_launcher__weapon1';
delete from public.vehicle_weapons w using public.vehicles v where v.id=w.vehicle_id and v.slug='ampv_30' and w.slug='brimstone__weapon1';
update public.vehicle_ammo a set ammo_type='atgm',is_missile=true,is_guided=true
from public.vehicle_weapons w where w.id=a.weapon_id and w.weapon_type='atgm' and a.ammo_subtype='KEM';
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,note)
values('20261001_parser_artifact_cleanup','completed',now(),now(),'Merged weapon parameters and invalid ammo association quarantined; AMPV launcher split repaired; replacement weapon names have no guessed parameters.') on conflict do nothing;

