set local lock_timeout='3s';set local statement_timeout='20s';
insert into private.aw_source_snapshots(entity_type,entity_id,payload) select 'weapon',id,to_jsonb(w) from public.vehicle_weapons w on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select vehicle_id,'weapon_'||slug,name,'weapon','research',note,source_url,'wiki',verification_status,last_checked_at
from public.vehicle_weapons where requires_research=true on conflict(vehicle_id,slug) do nothing;
insert into public.weapon_upgrade_links(weapon_id,upgrade_id,vehicle_id)
select w.id,u.id,w.vehicle_id from public.vehicle_weapons w join public.vehicle_upgrades u on u.vehicle_id=w.vehicle_id and u.slug='weapon_'||w.slug
where w.requires_research=true on conflict do nothing;
update public.vehicle_weapons set source_type='wiki',
 caliber_mm=case when name ~ '[0-9]+([.][0-9]+)?[ ]*mm' then (regexp_match(name,'([0-9]+([.][0-9]+)?)[ ]*mm'))[1]::numeric else null end
where source_type is null;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,row_counts,note)
values('20261001_legacy_weapons','completed',now(),now(),jsonb_build_object('weapons',(select count(*) from public.vehicle_weapons)),'Weapon snapshots; research links; caliber from explicit game weapon name.')
on conflict(batch_key) do nothing;

-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'ammo',a.id,to_jsonb(a) from public.vehicle_ammo a order by id limit 150 offset 0 on conflict do nothing;
insert into public.ammo_guidance_modes(ammo_id,mode_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 0) a cross join lateral unnest(a.traits) tag
where tag in ('self_guided','saclos','fire_and_forget') on conflict do nothing;
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 0) a cross join lateral unnest(a.traits) tag
where tag in(select code from public.ammo_traits) on conflict do nothing;
update public.vehicle_ammo a set source_type='wiki',
 ammo_type=case
 when a.ammo_subtype ilike '%ATGM%' then 'atgm'
 when a.ammo_subtype like 'APFSDS%' then 'apfsds'
 when a.ammo_subtype='APDS' then 'apds'
 when a.ammo_subtype='APCR' then 'apcr'
 else a.ammo_type end,
 is_missile=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_missile end,
 is_guided=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_guided end
where a.id in(select id from public.vehicle_ammo order by id limit 150 offset 0);
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,t.code,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 0) a
cross join public.ammo_traits t where
(t.code='top_attack' and a.ammo_subtype ~* 'Top.Attack')
or (t.code='tandem' and a.ammo_subtype ilike '%Tandem%')
or (t.code='thermobaric' and a.ammo_subtype ilike '%Thermobaric%')
or (t.code='programmable' and a.ammo_subtype ilike '%Programmable%')
or (t.code='multipurpose' and a.ammo_subtype='HEAT-MP')
or (t.code='kinetic_missile' and a.ammo_subtype='Hypersonic Kinetic ATGM')
or (t.code='pele' and a.ammo_subtype in ('PELE','AP-PELE'))
on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select w.vehicle_id,'ammo_'||w.slug||'_'||a.slug,a.name,'ammo','research',a.note,a.source_url,'wiki',a.verification_status,a.last_checked_at
from (select * from public.vehicle_ammo order by id limit 150 offset 0) a join public.vehicle_weapons w on w.id=a.weapon_id
where a.requires_research=true and a.name not like 'Next ►%' on conflict(vehicle_id,slug) do nothing;
insert into public.ammo_upgrade_links(ammo_id,weapon_id,vehicle_id,upgrade_id)
select a.id,w.id,w.vehicle_id,u.id from (select * from public.vehicle_ammo order by id limit 150 offset 0) a
join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicle_upgrades u on u.vehicle_id=w.vehicle_id and u.slug='ammo_'||w.slug||'_'||a.slug
where a.requires_research=true on conflict do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,row_counts)
values('20261001_legacy_ammo_0','completed',now(),now(),jsonb_build_object('ammo',(select count(*) from(select id from public.vehicle_ammo order by id limit 150 offset 0) x)))
on conflict(batch_key) do nothing;

-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'ammo',a.id,to_jsonb(a) from public.vehicle_ammo a order by id limit 150 offset 150 on conflict do nothing;
insert into public.ammo_guidance_modes(ammo_id,mode_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 150) a cross join lateral unnest(a.traits) tag
where tag in ('self_guided','saclos','fire_and_forget') on conflict do nothing;
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 150) a cross join lateral unnest(a.traits) tag
where tag in(select code from public.ammo_traits) on conflict do nothing;
update public.vehicle_ammo a set source_type='wiki',
 ammo_type=case
 when a.ammo_subtype ilike '%ATGM%' then 'atgm'
 when a.ammo_subtype like 'APFSDS%' then 'apfsds'
 when a.ammo_subtype='APDS' then 'apds'
 when a.ammo_subtype='APCR' then 'apcr'
 else a.ammo_type end,
 is_missile=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_missile end,
 is_guided=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_guided end
where a.id in(select id from public.vehicle_ammo order by id limit 150 offset 150);
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,t.code,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 150) a
cross join public.ammo_traits t where
(t.code='top_attack' and a.ammo_subtype ~* 'Top.Attack')
or (t.code='tandem' and a.ammo_subtype ilike '%Tandem%')
or (t.code='thermobaric' and a.ammo_subtype ilike '%Thermobaric%')
or (t.code='programmable' and a.ammo_subtype ilike '%Programmable%')
or (t.code='multipurpose' and a.ammo_subtype='HEAT-MP')
or (t.code='kinetic_missile' and a.ammo_subtype='Hypersonic Kinetic ATGM')
or (t.code='pele' and a.ammo_subtype in ('PELE','AP-PELE'))
on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select w.vehicle_id,'ammo_'||w.slug||'_'||a.slug,a.name,'ammo','research',a.note,a.source_url,'wiki',a.verification_status,a.last_checked_at
from (select * from public.vehicle_ammo order by id limit 150 offset 150) a join public.vehicle_weapons w on w.id=a.weapon_id
where a.requires_research=true and a.name not like 'Next ►%' on conflict(vehicle_id,slug) do nothing;
insert into public.ammo_upgrade_links(ammo_id,weapon_id,vehicle_id,upgrade_id)
select a.id,w.id,w.vehicle_id,u.id from (select * from public.vehicle_ammo order by id limit 150 offset 150) a
join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicle_upgrades u on u.vehicle_id=w.vehicle_id and u.slug='ammo_'||w.slug||'_'||a.slug
where a.requires_research=true on conflict do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,row_counts)
values('20261001_legacy_ammo_150','completed',now(),now(),jsonb_build_object('ammo',(select count(*) from(select id from public.vehicle_ammo order by id limit 150 offset 150) x)))
on conflict(batch_key) do nothing;

-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'ammo',a.id,to_jsonb(a) from public.vehicle_ammo a order by id limit 150 offset 300 on conflict do nothing;
insert into public.ammo_guidance_modes(ammo_id,mode_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 300) a cross join lateral unnest(a.traits) tag
where tag in ('self_guided','saclos','fire_and_forget') on conflict do nothing;
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 300) a cross join lateral unnest(a.traits) tag
where tag in(select code from public.ammo_traits) on conflict do nothing;
update public.vehicle_ammo a set source_type='wiki',
 ammo_type=case
 when a.ammo_subtype ilike '%ATGM%' then 'atgm'
 when a.ammo_subtype like 'APFSDS%' then 'apfsds'
 when a.ammo_subtype='APDS' then 'apds'
 when a.ammo_subtype='APCR' then 'apcr'
 else a.ammo_type end,
 is_missile=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_missile end,
 is_guided=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_guided end
where a.id in(select id from public.vehicle_ammo order by id limit 150 offset 300);
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,t.code,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 300) a
cross join public.ammo_traits t where
(t.code='top_attack' and a.ammo_subtype ~* 'Top.Attack')
or (t.code='tandem' and a.ammo_subtype ilike '%Tandem%')
or (t.code='thermobaric' and a.ammo_subtype ilike '%Thermobaric%')
or (t.code='programmable' and a.ammo_subtype ilike '%Programmable%')
or (t.code='multipurpose' and a.ammo_subtype='HEAT-MP')
or (t.code='kinetic_missile' and a.ammo_subtype='Hypersonic Kinetic ATGM')
or (t.code='pele' and a.ammo_subtype in ('PELE','AP-PELE'))
on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select w.vehicle_id,'ammo_'||w.slug||'_'||a.slug,a.name,'ammo','research',a.note,a.source_url,'wiki',a.verification_status,a.last_checked_at
from (select * from public.vehicle_ammo order by id limit 150 offset 300) a join public.vehicle_weapons w on w.id=a.weapon_id
where a.requires_research=true and a.name not like 'Next ►%' on conflict(vehicle_id,slug) do nothing;
insert into public.ammo_upgrade_links(ammo_id,weapon_id,vehicle_id,upgrade_id)
select a.id,w.id,w.vehicle_id,u.id from (select * from public.vehicle_ammo order by id limit 150 offset 300) a
join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicle_upgrades u on u.vehicle_id=w.vehicle_id and u.slug='ammo_'||w.slug||'_'||a.slug
where a.requires_research=true on conflict do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,row_counts)
values('20261001_legacy_ammo_300','completed',now(),now(),jsonb_build_object('ammo',(select count(*) from(select id from public.vehicle_ammo order by id limit 150 offset 300) x)))
on conflict(batch_key) do nothing;

-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'ammo',a.id,to_jsonb(a) from public.vehicle_ammo a order by id limit 150 offset 450 on conflict do nothing;
insert into public.ammo_guidance_modes(ammo_id,mode_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 450) a cross join lateral unnest(a.traits) tag
where tag in ('self_guided','saclos','fire_and_forget') on conflict do nothing;
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 450) a cross join lateral unnest(a.traits) tag
where tag in(select code from public.ammo_traits) on conflict do nothing;
update public.vehicle_ammo a set source_type='wiki',
 ammo_type=case
 when a.ammo_subtype ilike '%ATGM%' then 'atgm'
 when a.ammo_subtype like 'APFSDS%' then 'apfsds'
 when a.ammo_subtype='APDS' then 'apds'
 when a.ammo_subtype='APCR' then 'apcr'
 else a.ammo_type end,
 is_missile=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_missile end,
 is_guided=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_guided end
where a.id in(select id from public.vehicle_ammo order by id limit 150 offset 450);
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,t.code,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 450) a
cross join public.ammo_traits t where
(t.code='top_attack' and a.ammo_subtype ~* 'Top.Attack')
or (t.code='tandem' and a.ammo_subtype ilike '%Tandem%')
or (t.code='thermobaric' and a.ammo_subtype ilike '%Thermobaric%')
or (t.code='programmable' and a.ammo_subtype ilike '%Programmable%')
or (t.code='multipurpose' and a.ammo_subtype='HEAT-MP')
or (t.code='kinetic_missile' and a.ammo_subtype='Hypersonic Kinetic ATGM')
or (t.code='pele' and a.ammo_subtype in ('PELE','AP-PELE'))
on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select w.vehicle_id,'ammo_'||w.slug||'_'||a.slug,a.name,'ammo','research',a.note,a.source_url,'wiki',a.verification_status,a.last_checked_at
from (select * from public.vehicle_ammo order by id limit 150 offset 450) a join public.vehicle_weapons w on w.id=a.weapon_id
where a.requires_research=true and a.name not like 'Next ►%' on conflict(vehicle_id,slug) do nothing;
insert into public.ammo_upgrade_links(ammo_id,weapon_id,vehicle_id,upgrade_id)
select a.id,w.id,w.vehicle_id,u.id from (select * from public.vehicle_ammo order by id limit 150 offset 450) a
join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicle_upgrades u on u.vehicle_id=w.vehicle_id and u.slug='ammo_'||w.slug||'_'||a.slug
where a.requires_research=true on conflict do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,row_counts)
values('20261001_legacy_ammo_450','completed',now(),now(),jsonb_build_object('ammo',(select count(*) from(select id from public.vehicle_ammo order by id limit 150 offset 450) x)))
on conflict(batch_key) do nothing;

-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'ammo',a.id,to_jsonb(a) from public.vehicle_ammo a order by id limit 150 offset 600 on conflict do nothing;
insert into public.ammo_guidance_modes(ammo_id,mode_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 600) a cross join lateral unnest(a.traits) tag
where tag in ('self_guided','saclos','fire_and_forget') on conflict do nothing;
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 600) a cross join lateral unnest(a.traits) tag
where tag in(select code from public.ammo_traits) on conflict do nothing;
update public.vehicle_ammo a set source_type='wiki',
 ammo_type=case
 when a.ammo_subtype ilike '%ATGM%' then 'atgm'
 when a.ammo_subtype like 'APFSDS%' then 'apfsds'
 when a.ammo_subtype='APDS' then 'apds'
 when a.ammo_subtype='APCR' then 'apcr'
 else a.ammo_type end,
 is_missile=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_missile end,
 is_guided=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_guided end
where a.id in(select id from public.vehicle_ammo order by id limit 150 offset 600);
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,t.code,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 600) a
cross join public.ammo_traits t where
(t.code='top_attack' and a.ammo_subtype ~* 'Top.Attack')
or (t.code='tandem' and a.ammo_subtype ilike '%Tandem%')
or (t.code='thermobaric' and a.ammo_subtype ilike '%Thermobaric%')
or (t.code='programmable' and a.ammo_subtype ilike '%Programmable%')
or (t.code='multipurpose' and a.ammo_subtype='HEAT-MP')
or (t.code='kinetic_missile' and a.ammo_subtype='Hypersonic Kinetic ATGM')
or (t.code='pele' and a.ammo_subtype in ('PELE','AP-PELE'))
on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select w.vehicle_id,'ammo_'||w.slug||'_'||a.slug,a.name,'ammo','research',a.note,a.source_url,'wiki',a.verification_status,a.last_checked_at
from (select * from public.vehicle_ammo order by id limit 150 offset 600) a join public.vehicle_weapons w on w.id=a.weapon_id
where a.requires_research=true and a.name not like 'Next ►%' on conflict(vehicle_id,slug) do nothing;
insert into public.ammo_upgrade_links(ammo_id,weapon_id,vehicle_id,upgrade_id)
select a.id,w.id,w.vehicle_id,u.id from (select * from public.vehicle_ammo order by id limit 150 offset 600) a
join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicle_upgrades u on u.vehicle_id=w.vehicle_id and u.slug='ammo_'||w.slug||'_'||a.slug
where a.requires_research=true on conflict do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,row_counts)
values('20261001_legacy_ammo_600','completed',now(),now(),jsonb_build_object('ammo',(select count(*) from(select id from public.vehicle_ammo order by id limit 150 offset 600) x)))
on conflict(batch_key) do nothing;

-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'ammo',a.id,to_jsonb(a) from public.vehicle_ammo a order by id limit 150 offset 750 on conflict do nothing;
insert into public.ammo_guidance_modes(ammo_id,mode_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 750) a cross join lateral unnest(a.traits) tag
where tag in ('self_guided','saclos','fire_and_forget') on conflict do nothing;
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,tag,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 750) a cross join lateral unnest(a.traits) tag
where tag in(select code from public.ammo_traits) on conflict do nothing;
update public.vehicle_ammo a set source_type='wiki',
 ammo_type=case
 when a.ammo_subtype ilike '%ATGM%' then 'atgm'
 when a.ammo_subtype like 'APFSDS%' then 'apfsds'
 when a.ammo_subtype='APDS' then 'apds'
 when a.ammo_subtype='APCR' then 'apcr'
 else a.ammo_type end,
 is_missile=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_missile end,
 is_guided=case when a.ammo_subtype ilike '%ATGM%' then true else a.is_guided end
where a.id in(select id from public.vehicle_ammo order by id limit 150 offset 750);
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,t.code,a.source_url,'wiki',a.verification_status
from (select * from public.vehicle_ammo order by id limit 150 offset 750) a
cross join public.ammo_traits t where
(t.code='top_attack' and a.ammo_subtype ~* 'Top.Attack')
or (t.code='tandem' and a.ammo_subtype ilike '%Tandem%')
or (t.code='thermobaric' and a.ammo_subtype ilike '%Thermobaric%')
or (t.code='programmable' and a.ammo_subtype ilike '%Programmable%')
or (t.code='multipurpose' and a.ammo_subtype='HEAT-MP')
or (t.code='kinetic_missile' and a.ammo_subtype='Hypersonic Kinetic ATGM')
or (t.code='pele' and a.ammo_subtype in ('PELE','AP-PELE'))
on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select w.vehicle_id,'ammo_'||w.slug||'_'||a.slug,a.name,'ammo','research',a.note,a.source_url,'wiki',a.verification_status,a.last_checked_at
from (select * from public.vehicle_ammo order by id limit 150 offset 750) a join public.vehicle_weapons w on w.id=a.weapon_id
where a.requires_research=true and a.name not like 'Next ►%' on conflict(vehicle_id,slug) do nothing;
insert into public.ammo_upgrade_links(ammo_id,weapon_id,vehicle_id,upgrade_id)
select a.id,w.id,w.vehicle_id,u.id from (select * from public.vehicle_ammo order by id limit 150 offset 750) a
join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicle_upgrades u on u.vehicle_id=w.vehicle_id and u.slug='ammo_'||w.slug||'_'||a.slug
where a.requires_research=true on conflict do nothing;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,row_counts)
values('20261001_legacy_ammo_750','completed',now(),now(),jsonb_build_object('ammo',(select count(*) from(select id from public.vehicle_ammo order by id limit 150 offset 750) x)))
on conflict(batch_key) do nothing;
