set local lock_timeout='3s';set local statement_timeout='20s';
insert into public.vehicle_capabilities(vehicle_id,capability_code,variant_key,availability,upgrade_id,effect_description,source_url,source_type,verification_status,last_checked_at)
select u.vehicle_id,
 case when u.upgrade_type='era' then 'era' when u.upgrade_type='smoke' then 'smoke'
 when u.name ~* 'Hard[ -]Kill' then 'hard_kill_aps' when u.name ~* 'Soft[ -]Kill' then 'soft_kill_aps' else 'aps' end,
 u.slug,u.availability,u.id,u.effect_description,u.source_url,u.source_type,u.verification_status,u.last_checked_at
from public.vehicle_upgrades u where u.upgrade_type in ('era','smoke','aps')
on conflict(vehicle_id,capability_code,variant_key) do nothing;
delete from public.vehicle_capabilities b where b.variant_key='base' and exists(
 select 1 from public.vehicle_capabilities c where c.vehicle_id=b.vehicle_id and c.capability_code=b.capability_code and c.upgrade_id is not null
 and (c.availability=b.availability or b.availability='unknown'));
insert into public.vehicle_era(capability_id,era_name,generation)
select c.id,u.name,case when u.name ~ 'Gen[ ]+[0-9]+' then (regexp_match(u.name,'Gen[ ]+([0-9]+)'))[1]::smallint else null end
from public.vehicle_capabilities c join public.vehicle_upgrades u on u.id=c.upgrade_id where c.capability_code='era'
on conflict(capability_id) do update set era_name=excluded.era_name,generation=excluded.generation;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,note)
values('20261001_capability_upgrade_links','completed',now(),now(),'Typed module capability variants linked. Generation only parsed from explicit Gen N name; coverage/type/layers left unknown.')
on conflict do nothing;

