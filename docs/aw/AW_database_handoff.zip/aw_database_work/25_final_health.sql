set local statement_timeout='20s';
select jsonb_build_object(
 'checked_at',now(),
 'active_noninspection',(select count(*) from pg_stat_activity where datname=current_database() and pid<>pg_backend_pid() and state='active'),
 'idle_in_transaction',(select count(*) from pg_stat_activity where datname=current_database() and pid<>pg_backend_pid() and state like 'idle in transaction%'),
 'ungranted_locks',(select count(*) from pg_locks where not granted),
 'noncompleted_batches',(select count(*) from private.aw_import_batches where status<>'completed'),
 'invalid_indexes',(select count(*) from pg_index i join pg_class c on c.oid=i.indexrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname in ('public','private') and not i.indisvalid),
 'unvalidated_constraints',(select count(*) from pg_constraint c join pg_namespace n on n.oid=c.connamespace where n.nspname in ('public','private') and not c.convalidated),
 'duplicate_vehicle_slugs',(select count(*) from (select slug from public.vehicles group by slug having count(*)>1)s),
 'duplicate_weapon_configs',(select count(*) from (select vehicle_id,name,configuration_key from public.vehicle_weapons group by vehicle_id,name,configuration_key having count(*)>1)s),
 'orphans_ammo',(select count(*) from public.vehicle_ammo a left join public.vehicle_weapons w on w.id=a.weapon_id where w.id is null),
 'orphan_paths',(select count(*) from public.unlock_paths u left join public.vehicles v on v.id=u.vehicle_id where v.id is null),
 'test_vehicles',(select count(*) from public.vehicles where slug like '__test%' or slug like 'aw_test%'),
 'team_plans',(select count(*) from private.aw_fleet_plan_items),
 'unknown_ap_filter_false_positives',(select count(*) from public.search_aw_vehicles(p_min_ap_penetration=>800,p_availability=>'unknown') v where not exists(
 select 1 from public.vehicle_weapons w join public.vehicle_ammo a on a.weapon_id=w.id
 where w.vehicle_id=v.id and a.ammo_type in ('ap','apfsds','apds','apcr') and a.penetration>=800
 and a.requires_research is not true and w.requires_research is not true and (a.requires_research is null or w.requires_research is null)))
 ) audit;
