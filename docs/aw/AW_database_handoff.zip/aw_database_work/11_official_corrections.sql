set local lock_timeout='3s';set local statement_timeout='20s';
insert into public.vehicle_capabilities(vehicle_id,capability_code,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select v.id,x.code,x.availability,x.note,x.url,'official','public_verified',now()
from (values
 ('ampv_30','era','absent','官方游戏介绍明确无 ERA；此处不采用实车段落的 ERA。','https://armoredwarfare.com/en/news/general/development-ampv-30'),
 ('ampv_30','hard_kill_aps','absent','官方游戏介绍明确无硬杀 APS。','https://armoredwarfare.com/en/news/general/development-ampv-30'),
 ('ampv_30','infantry_squad','unknown','可以携带机械化步兵；与强化软杀 APS 存在选择关系，默认/研发口径待核实。','https://armoredwarfare.com/en/news/general/development-ampv-30'),
 ('ampv_30','recon','unknown','LRA 从第一人称控制并侦察，装载于 Javelin 发射器。','https://armoredwarfare.com/en/news/general/developer-diary-loitering-recon-ammunition'),
 ('boxer_riwp','infantry_squad','unknown','官方现行销售介绍确认可部署机械化步兵。','https://armoredwarfare.com/en/news/general/offer-firepower'),
 ('hunter_afv','infantry_squad','unknown','官方现行销售介绍确认可部署机械化步兵。','https://armoredwarfare.com/en/news/general/offer-firepower'),
 ('hunter_afv','nera','unknown','官方游戏段落确认 NERA；不能当 ERA。','https://armoredwarfare.com/en/news/general/offer-firepower')
) x(slug,code,availability,note,url) join public.vehicles v on v.slug=x.slug
on conflict(vehicle_id,capability_code,variant_key) do update set availability=excluded.availability,effect_description=excluded.effect_description,source_url=excluded.source_url,source_type=excluded.source_type,verification_status=excluded.verification_status,last_checked_at=excluded.last_checked_at;
insert into public.vehicle_infantry(capability_id)
select c.id from public.vehicle_capabilities c join public.vehicles v on v.id=c.vehicle_id where v.slug in ('ampv_30','boxer_riwp','hunter_afv') and c.capability_code='infantry_squad' on conflict do nothing;
update public.vehicles set is_premium=true,source_note=coalesce(source_note,'')||' 高级车身份由官方 https://armoredwarfare.com/en/news/general/offer-firepower 核实，性能数值仍沿用 Wiki 待核。'
where slug in ('boxer_riwp','t_15_kinzhal','leclerc_t40','hunter_afv','tos_1m_buratino','otomatic','abrams_agds','bmpt_mod_2017') and is_premium is distinct from true;
insert into public.ammo_guidance_modes(ammo_id,mode_code,source_url,source_type,verification_status)
select a.id,x.mode,x.url,'official','public_verified'
from public.vehicle_ammo a join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicles v on v.id=w.vehicle_id
cross join (values ('self_guided','https://armoredwarfare.com/en/news/general/offer-firepower'),
 ('fire_and_forget','https://armoredwarfare.com/en/news/general/development-leclerc-t40')) x(mode,url)
where v.slug='leclerc_t40' and w.name='Javelin ATGM Launcher'
on conflict(ammo_id,mode_code) do update set source_url=excluded.source_url,source_type=excluded.source_type,verification_status=excluded.verification_status;
insert into public.ammo_trait_links(ammo_id,trait_code,source_url,source_type,verification_status)
select a.id,'top_attack','https://armoredwarfare.com/en/news/general/offer-firepower','official','public_verified'
from public.vehicle_ammo a join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicles v on v.id=w.vehicle_id
where v.slug='leclerc_t40' and w.name='Javelin ATGM Launcher' on conflict do nothing;
update public.vehicle_era e set era_name='Malakhit',era_type='Malakhit',generation=4
from public.vehicle_capabilities c join public.vehicles v on v.id=c.vehicle_id
where e.capability_id=c.id and v.slug in ('t15_armata','t14_armata') and c.capability_code='era';
update public.vehicle_capabilities c set source_url=v.source_url,source_type='wiki',effect_description='Wiki 游戏装甲段落列出 Malakhit 与 Generation 4；覆盖位置、各弹种减穿比例仍待核。',last_checked_at=now()
from public.vehicles v where v.id=c.vehicle_id and v.slug in ('t15_armata','t14_armata') and c.capability_code='era';
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,note)
values('20261001_official_capability_corrections','completed',now(),now(),'AMPV explicit ERA absence; infantry and NERA; Leclerc T40 self-guided/fire-and-forget/top-attack. Historical development numbers not substituted for current stats.')
on conflict do nothing;
