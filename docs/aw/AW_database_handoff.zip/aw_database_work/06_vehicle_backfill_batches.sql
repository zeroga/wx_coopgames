set local lock_timeout='3s';set local statement_timeout='20s';set local idle_in_transaction_session_timeout='30s';
insert into private.aw_import_batches(batch_key,status,started_at) values('20261001_legacy_vehicle_0','running',now()) on conflict(batch_key) do nothing;
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'vehicle',v.id,to_jsonb(v) from public.vehicles v order by v.slug limit 50 offset 0 on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,xp_cost,hp_bonus,top_speed_kmh,reverse_speed_kmh,effect_description,additional_effects,source_url,source_type,verification_status,last_checked_at)
select v.id,'component_'||md5(c->>'name'),c->>'name',
case when c->>'component_type'='engine' then 'engine'
 when c->>'name' ~* 'ERA|Reactive Armor' then 'era'
 when c->>'name' ~* 'Smoke' then 'smoke'
 when c->>'name' ~* 'APS|Active Protection' then 'aps'
 when c->>'name' ~* 'Optics|Vision' then 'optics'
 when c->>'name' ~* 'Tracks' then 'mobility'
 when c->>'name' ~* 'loader|Loading|Cooling' then 'loading'
 when c->>'name' ~* 'Spall|Crew Compartment' then 'protection' else 'other' end,
case when (c->>'requires_research')::boolean=true then 'research' when (c->>'requires_research')::boolean=false then 'default' else 'unknown' end,
(c->>'xp_cost')::numeric,(c->>'hp_bonus')::integer,(c->>'top_speed')::numeric,(c->>'reverse_speed')::numeric,c->>'note',
c - array['name','requires_research','xp_cost','hp_bonus','top_speed','reverse_speed','note','source_url','component_type'],
coalesce(c->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 0) v
cross join lateral jsonb_array_elements(v.researchable_components) c where c->>'name' is not null
on conflict(vehicle_id,slug) do nothing;
insert into public.vehicle_capabilities(vehicle_id,capability_code,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select v.id,tag,
case when (v.trait_details->tag->>'requires_research')::boolean=true then 'research'
 when (v.trait_details->tag->>'requires_research')::boolean=false then 'default' else 'unknown' end,
v.trait_details->tag->>'note',coalesce(v.trait_details->tag->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 0) v cross join lateral unnest(v.traits) tag
where tag not in ('atgm','autocannon')
and not(tag='aps' and (v.traits && array['hard_kill_aps','soft_kill_aps']))
on conflict(vehicle_id,capability_code,variant_key) do nothing;
insert into public.vehicle_era(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 0) v on v.id=vc.vehicle_id
where vc.capability_code='era' and vc.availability<>'absent' on conflict do nothing;
insert into public.vehicle_infantry(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 0) v on v.id=vc.vehicle_id
where vc.capability_code='infantry_squad' and vc.availability<>'absent' on conflict do nothing;
update public.vehicles set source_type='wiki' where id in(select id from public.vehicles order by slug limit 50 offset 0) and source_type is null;
update private.aw_import_batches set status='completed',completed_at=now(),row_counts=jsonb_build_object('vehicles',(select count(*) from(select id from public.vehicles order by slug limit 50 offset 0) x)),note='Raw snapshot preserved; normalized upgrades and capabilities imported. Legacy verification status retained.' where batch_key='20261001_legacy_vehicle_0';


-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';set local idle_in_transaction_session_timeout='30s';
insert into private.aw_import_batches(batch_key,status,started_at) values('20261001_legacy_vehicle_50','running',now()) on conflict(batch_key) do nothing;
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'vehicle',v.id,to_jsonb(v) from public.vehicles v order by v.slug limit 50 offset 50 on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,xp_cost,hp_bonus,top_speed_kmh,reverse_speed_kmh,effect_description,additional_effects,source_url,source_type,verification_status,last_checked_at)
select v.id,'component_'||md5(c->>'name'),c->>'name',
case when c->>'component_type'='engine' then 'engine'
 when c->>'name' ~* 'ERA|Reactive Armor' then 'era'
 when c->>'name' ~* 'Smoke' then 'smoke'
 when c->>'name' ~* 'APS|Active Protection' then 'aps'
 when c->>'name' ~* 'Optics|Vision' then 'optics'
 when c->>'name' ~* 'Tracks' then 'mobility'
 when c->>'name' ~* 'loader|Loading|Cooling' then 'loading'
 when c->>'name' ~* 'Spall|Crew Compartment' then 'protection' else 'other' end,
case when (c->>'requires_research')::boolean=true then 'research' when (c->>'requires_research')::boolean=false then 'default' else 'unknown' end,
(c->>'xp_cost')::numeric,(c->>'hp_bonus')::integer,(c->>'top_speed')::numeric,(c->>'reverse_speed')::numeric,c->>'note',
c - array['name','requires_research','xp_cost','hp_bonus','top_speed','reverse_speed','note','source_url','component_type'],
coalesce(c->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 50) v
cross join lateral jsonb_array_elements(v.researchable_components) c where c->>'name' is not null
on conflict(vehicle_id,slug) do nothing;
insert into public.vehicle_capabilities(vehicle_id,capability_code,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select v.id,tag,
case when (v.trait_details->tag->>'requires_research')::boolean=true then 'research'
 when (v.trait_details->tag->>'requires_research')::boolean=false then 'default' else 'unknown' end,
v.trait_details->tag->>'note',coalesce(v.trait_details->tag->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 50) v cross join lateral unnest(v.traits) tag
where tag not in ('atgm','autocannon')
and not(tag='aps' and (v.traits && array['hard_kill_aps','soft_kill_aps']))
on conflict(vehicle_id,capability_code,variant_key) do nothing;
insert into public.vehicle_era(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 50) v on v.id=vc.vehicle_id
where vc.capability_code='era' and vc.availability<>'absent' on conflict do nothing;
insert into public.vehicle_infantry(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 50) v on v.id=vc.vehicle_id
where vc.capability_code='infantry_squad' and vc.availability<>'absent' on conflict do nothing;
update public.vehicles set source_type='wiki' where id in(select id from public.vehicles order by slug limit 50 offset 50) and source_type is null;
update private.aw_import_batches set status='completed',completed_at=now(),row_counts=jsonb_build_object('vehicles',(select count(*) from(select id from public.vehicles order by slug limit 50 offset 50) x)),note='Raw snapshot preserved; normalized upgrades and capabilities imported. Legacy verification status retained.' where batch_key='20261001_legacy_vehicle_50';


-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';set local idle_in_transaction_session_timeout='30s';
insert into private.aw_import_batches(batch_key,status,started_at) values('20261001_legacy_vehicle_100','running',now()) on conflict(batch_key) do nothing;
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'vehicle',v.id,to_jsonb(v) from public.vehicles v order by v.slug limit 50 offset 100 on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,xp_cost,hp_bonus,top_speed_kmh,reverse_speed_kmh,effect_description,additional_effects,source_url,source_type,verification_status,last_checked_at)
select v.id,'component_'||md5(c->>'name'),c->>'name',
case when c->>'component_type'='engine' then 'engine'
 when c->>'name' ~* 'ERA|Reactive Armor' then 'era'
 when c->>'name' ~* 'Smoke' then 'smoke'
 when c->>'name' ~* 'APS|Active Protection' then 'aps'
 when c->>'name' ~* 'Optics|Vision' then 'optics'
 when c->>'name' ~* 'Tracks' then 'mobility'
 when c->>'name' ~* 'loader|Loading|Cooling' then 'loading'
 when c->>'name' ~* 'Spall|Crew Compartment' then 'protection' else 'other' end,
case when (c->>'requires_research')::boolean=true then 'research' when (c->>'requires_research')::boolean=false then 'default' else 'unknown' end,
(c->>'xp_cost')::numeric,(c->>'hp_bonus')::integer,(c->>'top_speed')::numeric,(c->>'reverse_speed')::numeric,c->>'note',
c - array['name','requires_research','xp_cost','hp_bonus','top_speed','reverse_speed','note','source_url','component_type'],
coalesce(c->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 100) v
cross join lateral jsonb_array_elements(v.researchable_components) c where c->>'name' is not null
on conflict(vehicle_id,slug) do nothing;
insert into public.vehicle_capabilities(vehicle_id,capability_code,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select v.id,tag,
case when (v.trait_details->tag->>'requires_research')::boolean=true then 'research'
 when (v.trait_details->tag->>'requires_research')::boolean=false then 'default' else 'unknown' end,
v.trait_details->tag->>'note',coalesce(v.trait_details->tag->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 100) v cross join lateral unnest(v.traits) tag
where tag not in ('atgm','autocannon')
and not(tag='aps' and (v.traits && array['hard_kill_aps','soft_kill_aps']))
on conflict(vehicle_id,capability_code,variant_key) do nothing;
insert into public.vehicle_era(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 100) v on v.id=vc.vehicle_id
where vc.capability_code='era' and vc.availability<>'absent' on conflict do nothing;
insert into public.vehicle_infantry(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 100) v on v.id=vc.vehicle_id
where vc.capability_code='infantry_squad' and vc.availability<>'absent' on conflict do nothing;
update public.vehicles set source_type='wiki' where id in(select id from public.vehicles order by slug limit 50 offset 100) and source_type is null;
update private.aw_import_batches set status='completed',completed_at=now(),row_counts=jsonb_build_object('vehicles',(select count(*) from(select id from public.vehicles order by slug limit 50 offset 100) x)),note='Raw snapshot preserved; normalized upgrades and capabilities imported. Legacy verification status retained.' where batch_key='20261001_legacy_vehicle_100';


-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';set local idle_in_transaction_session_timeout='30s';
insert into private.aw_import_batches(batch_key,status,started_at) values('20261001_legacy_vehicle_150','running',now()) on conflict(batch_key) do nothing;
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'vehicle',v.id,to_jsonb(v) from public.vehicles v order by v.slug limit 50 offset 150 on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,xp_cost,hp_bonus,top_speed_kmh,reverse_speed_kmh,effect_description,additional_effects,source_url,source_type,verification_status,last_checked_at)
select v.id,'component_'||md5(c->>'name'),c->>'name',
case when c->>'component_type'='engine' then 'engine'
 when c->>'name' ~* 'ERA|Reactive Armor' then 'era'
 when c->>'name' ~* 'Smoke' then 'smoke'
 when c->>'name' ~* 'APS|Active Protection' then 'aps'
 when c->>'name' ~* 'Optics|Vision' then 'optics'
 when c->>'name' ~* 'Tracks' then 'mobility'
 when c->>'name' ~* 'loader|Loading|Cooling' then 'loading'
 when c->>'name' ~* 'Spall|Crew Compartment' then 'protection' else 'other' end,
case when (c->>'requires_research')::boolean=true then 'research' when (c->>'requires_research')::boolean=false then 'default' else 'unknown' end,
(c->>'xp_cost')::numeric,(c->>'hp_bonus')::integer,(c->>'top_speed')::numeric,(c->>'reverse_speed')::numeric,c->>'note',
c - array['name','requires_research','xp_cost','hp_bonus','top_speed','reverse_speed','note','source_url','component_type'],
coalesce(c->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 150) v
cross join lateral jsonb_array_elements(v.researchable_components) c where c->>'name' is not null
on conflict(vehicle_id,slug) do nothing;
insert into public.vehicle_capabilities(vehicle_id,capability_code,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select v.id,tag,
case when (v.trait_details->tag->>'requires_research')::boolean=true then 'research'
 when (v.trait_details->tag->>'requires_research')::boolean=false then 'default' else 'unknown' end,
v.trait_details->tag->>'note',coalesce(v.trait_details->tag->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 150) v cross join lateral unnest(v.traits) tag
where tag not in ('atgm','autocannon')
and not(tag='aps' and (v.traits && array['hard_kill_aps','soft_kill_aps']))
on conflict(vehicle_id,capability_code,variant_key) do nothing;
insert into public.vehicle_era(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 150) v on v.id=vc.vehicle_id
where vc.capability_code='era' and vc.availability<>'absent' on conflict do nothing;
insert into public.vehicle_infantry(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 150) v on v.id=vc.vehicle_id
where vc.capability_code='infantry_squad' and vc.availability<>'absent' on conflict do nothing;
update public.vehicles set source_type='wiki' where id in(select id from public.vehicles order by slug limit 50 offset 150) and source_type is null;
update private.aw_import_batches set status='completed',completed_at=now(),row_counts=jsonb_build_object('vehicles',(select count(*) from(select id from public.vehicles order by slug limit 50 offset 150) x)),note='Raw snapshot preserved; normalized upgrades and capabilities imported. Legacy verification status retained.' where batch_key='20261001_legacy_vehicle_150';


-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';set local idle_in_transaction_session_timeout='30s';
insert into private.aw_import_batches(batch_key,status,started_at) values('20261001_legacy_vehicle_200','running',now()) on conflict(batch_key) do nothing;
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'vehicle',v.id,to_jsonb(v) from public.vehicles v order by v.slug limit 50 offset 200 on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,xp_cost,hp_bonus,top_speed_kmh,reverse_speed_kmh,effect_description,additional_effects,source_url,source_type,verification_status,last_checked_at)
select v.id,'component_'||md5(c->>'name'),c->>'name',
case when c->>'component_type'='engine' then 'engine'
 when c->>'name' ~* 'ERA|Reactive Armor' then 'era'
 when c->>'name' ~* 'Smoke' then 'smoke'
 when c->>'name' ~* 'APS|Active Protection' then 'aps'
 when c->>'name' ~* 'Optics|Vision' then 'optics'
 when c->>'name' ~* 'Tracks' then 'mobility'
 when c->>'name' ~* 'loader|Loading|Cooling' then 'loading'
 when c->>'name' ~* 'Spall|Crew Compartment' then 'protection' else 'other' end,
case when (c->>'requires_research')::boolean=true then 'research' when (c->>'requires_research')::boolean=false then 'default' else 'unknown' end,
(c->>'xp_cost')::numeric,(c->>'hp_bonus')::integer,(c->>'top_speed')::numeric,(c->>'reverse_speed')::numeric,c->>'note',
c - array['name','requires_research','xp_cost','hp_bonus','top_speed','reverse_speed','note','source_url','component_type'],
coalesce(c->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 200) v
cross join lateral jsonb_array_elements(v.researchable_components) c where c->>'name' is not null
on conflict(vehicle_id,slug) do nothing;
insert into public.vehicle_capabilities(vehicle_id,capability_code,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select v.id,tag,
case when (v.trait_details->tag->>'requires_research')::boolean=true then 'research'
 when (v.trait_details->tag->>'requires_research')::boolean=false then 'default' else 'unknown' end,
v.trait_details->tag->>'note',coalesce(v.trait_details->tag->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 200) v cross join lateral unnest(v.traits) tag
where tag not in ('atgm','autocannon')
and not(tag='aps' and (v.traits && array['hard_kill_aps','soft_kill_aps']))
on conflict(vehicle_id,capability_code,variant_key) do nothing;
insert into public.vehicle_era(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 200) v on v.id=vc.vehicle_id
where vc.capability_code='era' and vc.availability<>'absent' on conflict do nothing;
insert into public.vehicle_infantry(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 200) v on v.id=vc.vehicle_id
where vc.capability_code='infantry_squad' and vc.availability<>'absent' on conflict do nothing;
update public.vehicles set source_type='wiki' where id in(select id from public.vehicles order by slug limit 50 offset 200) and source_type is null;
update private.aw_import_batches set status='completed',completed_at=now(),row_counts=jsonb_build_object('vehicles',(select count(*) from(select id from public.vehicles order by slug limit 50 offset 200) x)),note='Raw snapshot preserved; normalized upgrades and capabilities imported. Legacy verification status retained.' where batch_key='20261001_legacy_vehicle_200';


-- NEXT INDEPENDENT REQUEST / COMMIT BATCH

set local lock_timeout='3s';set local statement_timeout='20s';set local idle_in_transaction_session_timeout='30s';
insert into private.aw_import_batches(batch_key,status,started_at) values('20261001_legacy_vehicle_250','running',now()) on conflict(batch_key) do nothing;
insert into private.aw_source_snapshots(entity_type,entity_id,payload)
select 'vehicle',v.id,to_jsonb(v) from public.vehicles v order by v.slug limit 50 offset 250 on conflict do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,xp_cost,hp_bonus,top_speed_kmh,reverse_speed_kmh,effect_description,additional_effects,source_url,source_type,verification_status,last_checked_at)
select v.id,'component_'||md5(c->>'name'),c->>'name',
case when c->>'component_type'='engine' then 'engine'
 when c->>'name' ~* 'ERA|Reactive Armor' then 'era'
 when c->>'name' ~* 'Smoke' then 'smoke'
 when c->>'name' ~* 'APS|Active Protection' then 'aps'
 when c->>'name' ~* 'Optics|Vision' then 'optics'
 when c->>'name' ~* 'Tracks' then 'mobility'
 when c->>'name' ~* 'loader|Loading|Cooling' then 'loading'
 when c->>'name' ~* 'Spall|Crew Compartment' then 'protection' else 'other' end,
case when (c->>'requires_research')::boolean=true then 'research' when (c->>'requires_research')::boolean=false then 'default' else 'unknown' end,
(c->>'xp_cost')::numeric,(c->>'hp_bonus')::integer,(c->>'top_speed')::numeric,(c->>'reverse_speed')::numeric,c->>'note',
c - array['name','requires_research','xp_cost','hp_bonus','top_speed','reverse_speed','note','source_url','component_type'],
coalesce(c->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 250) v
cross join lateral jsonb_array_elements(v.researchable_components) c where c->>'name' is not null
on conflict(vehicle_id,slug) do nothing;
insert into public.vehicle_capabilities(vehicle_id,capability_code,availability,effect_description,source_url,source_type,verification_status,last_checked_at)
select v.id,tag,
case when (v.trait_details->tag->>'requires_research')::boolean=true then 'research'
 when (v.trait_details->tag->>'requires_research')::boolean=false then 'default' else 'unknown' end,
v.trait_details->tag->>'note',coalesce(v.trait_details->tag->>'source_url',v.source_url),'wiki',v.verification_status,v.last_checked_at
from (select * from public.vehicles order by slug limit 50 offset 250) v cross join lateral unnest(v.traits) tag
where tag not in ('atgm','autocannon')
and not(tag='aps' and (v.traits && array['hard_kill_aps','soft_kill_aps']))
on conflict(vehicle_id,capability_code,variant_key) do nothing;
insert into public.vehicle_era(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 250) v on v.id=vc.vehicle_id
where vc.capability_code='era' and vc.availability<>'absent' on conflict do nothing;
insert into public.vehicle_infantry(capability_id)
select vc.id from public.vehicle_capabilities vc join (select id from public.vehicles order by slug limit 50 offset 250) v on v.id=vc.vehicle_id
where vc.capability_code='infantry_squad' and vc.availability<>'absent' on conflict do nothing;
update public.vehicles set source_type='wiki' where id in(select id from public.vehicles order by slug limit 50 offset 250) and source_type is null;
update private.aw_import_batches set status='completed',completed_at=now(),row_counts=jsonb_build_object('vehicles',(select count(*) from(select id from public.vehicles order by slug limit 50 offset 250) x)),note='Raw snapshot preserved; normalized upgrades and capabilities imported. Legacy verification status retained.' where batch_key='20261001_legacy_vehicle_250';

