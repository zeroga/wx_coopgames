set local lock_timeout='3s';set local statement_timeout='20s';
insert into private.aw_source_snapshots(entity_type,entity_id,payload) select 'token_reward',id,to_jsonb(r) from public.vehicle_token_rewards r on conflict do nothing;
insert into private.aw_source_snapshots(entity_type,entity_id,payload) select 'unlock_requirement',id,to_jsonb(r) from public.unlock_requirements r on conflict do nothing;
insert into public.tokens(code,name,dealer_id,tier,source_url,source_type)
select token_code,replace(token_code,'_',' ')||' Unlock Token',dealer_id,token_tier,source_url,'wiki' from (
 select distinct on(token_code) token_code,dealer_id,token_tier,source_url from public.vehicle_token_rewards order by token_code
) x on conflict(code) do nothing;
insert into public.tokens(code,name,dealer_id,tier,source_url,source_type)
select token_code,replace(token_code,'_',' ')||' Unlock Token',dealer_id,(scope->>'token_tier')::smallint,source_url,'wiki'
from (select distinct on(token_code) * from public.unlock_requirements where token_code is not null order by token_code) x on conflict(code) do nothing;
update public.vehicle_token_rewards r set token_id=t.id from public.tokens t where t.code=r.token_code and r.token_id is null;
update public.unlock_requirements r set token_id=t.id from public.tokens t where t.code=r.token_code and r.token_id is null;
update public.unlock_requirements set source_type='wiki' where source_type is null;
insert into private.aw_data_issues(issue_key,entity_type,entity_id,severity,description,original_data,resolved_at)
select 'bad_ammo_navigation_'||slug,'ammo',id,'error','网页导航文字被误解析为弹药；已隔离原始记录。',to_jsonb(a),now()
from public.vehicle_ammo a where name like 'Next ►%' on conflict do nothing;
delete from public.vehicle_ammo where name like 'Next ►%';
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,note)
values('20261001_token_normalization','completed',now(),now(),'Normalized token definitions; preserved requirements and rewards; navigation artifact quarantined.') on conflict do nothing;

