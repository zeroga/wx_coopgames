set local lock_timeout='3s';set local statement_timeout='20s';
with source_rows(slug,name,ammo_type,ammo_subtype,damage,penetration,velocity,reload_seconds,requires_research,xp_cost,magazine_size,intra_clip_reload,accuracy_deg,magazine_mechanism) as (values ('b1_centauro_120','120mm DM53A1 APFSDS','apfsds','APFSDS',550,730,1650,6,false,null,6,4,0.12,'ready_rack'),
('b1_centauro_120','120mm DM63 APFSDS','apfsds','APFSDS',570,800,1650,6,true,120330,6,4,0.12,'ready_rack'),
('b1_centauro_120','120mm DM11 HE','he','HE',825,50,980,6,false,null,6,4,0.15,'ready_rack'),
('m8_120_thunderbolt_ii','120mm M829A2 APFSDS','apfsds','APFSDS-DU',550,730,1680,4,false,null,null,null,0.12,null),
('m8_120_thunderbolt_ii','120mm M829A3 APFSDS','apfsds','APFSDS-MDU',570,800,1555,4,true,139655,null,null,0.12,null),
('m8_120_thunderbolt_ii','120mm M830A1 HEAT-MP','heat','HEAT-MP',684,870,1140,4,false,null,null,null,0.13,null))
insert into public.vehicle_ammo(weapon_id,slug,name,ammo_type,ammo_subtype,damage,penetration,velocity,reload_seconds,requires_research,magazine_size,intra_clip_reload,accuracy_deg,magazine_mechanism,source_url,source_type,verification_status,last_checked_at,note)
select w.id,'wiki_'||md5(s.name),s.name,s.ammo_type,s.ammo_subtype,s.damage,s.penetration,s.velocity,s.reload_seconds,s.requires_research,s.magazine_size,s.intra_clip_reload,s.accuracy_deg,s.magazine_mechanism,v.source_url,'wiki','needs_ingame_check',now(),'Wiki 表格明确数值；穿深距离和角度未给出，保持 NULL。当前游戏版本待核。'
from source_rows s join public.vehicles v on v.slug=s.slug join public.vehicle_weapons w on w.vehicle_id=v.id and w.weapon_type='cannon'
on conflict(weapon_id,slug) do nothing;
insert into public.vehicle_upgrades(vehicle_id,slug,name,upgrade_type,availability,xp_cost,source_url,source_type,verification_status,last_checked_at)
select v.id,'ammo_'||w.slug||'_'||a.slug,a.name,'ammo','research',
case when a.name='120mm DM63 APFSDS' then 120330 when a.name='120mm M829A3 APFSDS' then 139655 else null end,
a.source_url,'wiki','needs_ingame_check',now()
from public.vehicle_ammo a join public.vehicle_weapons w on w.id=a.weapon_id join public.vehicles v on v.id=w.vehicle_id
where v.slug in ('b1_centauro_120','m8_120_thunderbolt_ii') and a.requires_research=true
on conflict(vehicle_id,slug) do nothing;
insert into public.ammo_upgrade_links(ammo_id,weapon_id,vehicle_id,upgrade_id)
select a.id,w.id,w.vehicle_id,u.id from public.vehicle_ammo a join public.vehicle_weapons w on w.id=a.weapon_id
join public.vehicle_upgrades u on u.vehicle_id=w.vehicle_id and u.slug='ammo_'||w.slug||'_'||a.slug
where a.requires_research=true on conflict do nothing;
insert into public.vehicle_crew_positions(vehicle_id,position_key,role,source_url,source_type,verification_status,note)
select v.id,r.role,r.role,v.source_url,'wiki','needs_ingame_check','Wiki Crew 明确列出；Commander 单独计入总岗位，不等同可训练车组人数。'
from public.vehicles v cross join(values('commander'),('driver'),('gunner'),('loader')) r(role)
where v.slug='b1_centauro_120' on conflict do nothing;
insert into public.vehicle_armor(vehicle_id,location,effective_ap_mm,effective_heat_mm,composition,source_url,source_type,verification_status)
select v.id,r.location,r.ap,r.heat,'Steel',v.source_url,'wiki','needs_ingame_check'
from public.vehicles v cross join(values('hull_unspecified',110,135),('turret_unspecified',110,145)) r(location,ap,heat)
where v.slug='b1_centauro_120' on conflict(vehicle_id,configuration_key,location) do nothing;
insert into public.vehicle_armor(vehicle_id,location,effective_ap_mm,effective_heat_mm,composition,source_url,source_type,verification_status)
select v.id,r.location,r.ap,r.heat,'Steel',v.source_url,'wiki','needs_ingame_check'
from public.vehicles v cross join(values('hull_unspecified',180,255),('turret_unspecified',380,735)) r(location,ap,heat)
where v.slug='m8_120_thunderbolt_ii' on conflict(vehicle_id,configuration_key,location) do nothing;
update public.vehicles set acceleration_0_32_seconds=3.9 where slug='b1_centauro_120' and acceleration_0_32_seconds is null;
insert into private.aw_import_batches(batch_key,status,started_at,completed_at,note)
values('20261001_missing_ammo_examples','completed',now(),now(),'6 Wiki shells on two formerly empty vehicles, 4 armor panel records, Centauro crew positions. Units preserved explicitly; distances/angles left NULL.')
on conflict do nothing;
